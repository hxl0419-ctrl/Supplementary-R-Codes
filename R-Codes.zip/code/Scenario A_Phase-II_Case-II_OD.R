library("vars")
library("MASS")
library("stats4")
library("splines")
library("VGAM")
library("tcltk")
library("gamlss")
library("HMMpa")
library("tseries")
library("forecast")

###########Scenario A
set.seed(666)
T <- 200
S <- 2
loop=200


X=rnorm(T,0.5,0.25)##covariate 
Z=rnorm(T,0.5,0.25)

##########model parameter initial setting ################### 
m=1
beta_init=0.1
gamma_init=0.2
theta_init=cbind(t(beta_init),t(gamma_init))
F0=diag(c(0.5,0.8),(2*m),(2*m))
Q0=diag(0.05,(2*m),(2*m))

theta=array(0,dim = c(T,(2*m)))
epsi_mu=rep(0,(2*m))

##################state space parameter###########################################
theta[1,]=F0%*%t(theta_init)+mvrnorm(1,epsi_mu,Q0)
alpha=rep(0,T)
alpha[1]=exp(theta[1,1]*X[1])/(1+exp(theta[1,1]*X[1]))
phi=rep(0,T)
phi[1]=1/(1+exp(theta[1,2]*Z[1]))
for (t in 1:(T-1)) {
  theta[(t+1),]=F0%*%theta[t,]+mvrnorm(1,epsi_mu,Q0)
  alpha[t+1]=exp(theta[(t+1),1]*X[t+1])/(1+exp(theta[(t+1),1]*X[t+1]))
  phi[t+1]=1/(1+exp(theta[(t+1),2]*Z[t+1]))
}

#generate INAR Phase-I sample
data_Y=c()
Y <-3#####given initial observed value
for(t in 1:T) {
  
  Y <- rbinom(1,Y,alpha[t])+rgeom(1,phi[t])
  data_Y <- c(data_Y,Y)
}


##################Phase-II
T=200
N=700
T1=N-T

theta=rbind(theta,array(0,dim = c((T1+1),S)))
alpha=rep(0,N)
phi=rep(0,N)

############################Generate test sample  

e_control_limit=10
loop=2000
ss=1

rl_shift=rep(0,8)
for (delta in c(0, 0.02, 0.04, 0.06, 0.08, 0.1, 0.2, 0.4)) {
  
  rl=rep(0,loop)
  for (ll in 1:loop) {
    
    
    X[(T+1):N]=rnorm(T1,0.5,0.25)##covariate 
    Z[(T+1):N]=rnorm(T1,0.5,0.25)
    
    for (t in T:N) {
      
      alpha[t]=exp(theta[t,1]*X[t])/(1+exp(theta[t,1]*X[t]))
      phi[t]=1/(1+exp(theta[t,2]*Z[t]))
      theta[(t+1),]=F0%*%theta[t,]+mvrnorm(1,epsi_mu,Q0)+c(0,delta)
    }
    data_Y_ex=c()
    Y=data_Y[T]
    for(t in (T+1):N) {
      Y <- rbinom(1,Y,alpha[t])+rgeom(1,phi[t])
      data_Y_ex <- c(data_Y_ex,Y)
    }
    data_Y[(T+1):N]=data_Y_ex
    
    
    ###################################control chart  
    OD=data_Y[(T+1):N]
    
    ##############################control chart
    
    if(min(which(OD>e_control_limit)) < Inf){
      rl[ll]=min(which(OD>e_control_limit))
    }
    if(min(which(OD>e_control_limit))==Inf){
      rl[ll]=T1
    }
    print(c(ll,rl[ll]))
  }
  median(rl)
  rl_shift[ss]=median(rl)
  ss=ss+1
}
rl_shift

deltaw=rep(0,8)
deltaw1=c(0, 0.02, 0.04, 0.06, 0.08, 0.1, 0.2, 0.4)

rl_result=data.frame(T,e_control_limit,0.5,0.8,0.05,0.05,beta_init,gamma_init,deltaw,deltaw1,rl_shift)
colnames(rl_result)=c("reference_sample_size","UCL","F0[1,1]","F0[2,2]","Q0[1,1]","Q0[2,2]","beta0","gamma0","alpha_shift","phi_shift","MRL")

write.csv(rl_result,file = "G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\OD\\Scenario_A\\Phase-II_Case-II.csv")





