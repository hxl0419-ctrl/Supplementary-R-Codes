library("vars")
library("MASS")
library("stats4")
library("splines")
library("VGAM")
library("tcltk")
library("gamlss")
library("HMMpa")
library("tseries")
library("forecast")

###########Scenario A
set.seed(666)
T <- 200
S <- 2
loop=200

FF00=array(0,dim=c(S,S,loop))
QQ00=array(0,dim=c(S,S,loop))
beta_test_init=array(0,dim=c(1,S,loop))

X=rnorm(T,0.5,0.25)##covariate 
Z=rnorm(T,0.5,0.25)
X_orin=X
Z_orin=Z
##########model parameter initial setting ################### 
m=1
beta_init=0.1
gamma_init=0.2
theta_init=cbind(t(beta_init),t(gamma_init))
F0=diag(c(0.5,0.8),(2*m),(2*m))
Q0=diag(0.05,(2*m),(2*m))
F0_s=F0
Q0_s=Q0
theta=array(0,dim = c(T,(2*m)))
epsi_mu=rep(0,(2*m))

##################state space parameter###########################################
theta[1,]=F0%*%t(theta_init)+mvrnorm(1,epsi_mu,Q0)
alpha=rep(0,T)
alpha[1]=exp(theta[1,1]*X[1])/(1+exp(theta[1,1]*X[1]))
phi=rep(0,T)
phi[1]=1/(1+exp(theta[1,2]*Z[1]))
for (t in 1:(T-1)) {
  theta[(t+1),]=F0%*%theta[t,]+mvrnorm(1,epsi_mu,Q0)
  alpha[t+1]=exp(theta[(t+1),1]*X[t+1])/(1+exp(theta[(t+1),1]*X[t+1]))
  phi[t+1]=1/(1+exp(theta[(t+1),2]*Z[t+1]))
}

#generate INAR Phase-I sample
data_Y=c()
Y <-3#####given initial observed value
for(t in 1:T) {
  
  Y <- rbinom(1,Y,alpha[t])+rgeom(1,phi[t])
  data_Y <- c(data_Y,Y)
}
data_Y_orin=data_Y
###revised moving block bootstrap (MBB) approach
data_Y_number=tsbootstrap(1:200,nb=199,b=100,type = "block")
data_Y_number=cbind(1:200,data_Y_number)
data_Y_boot <- apply(data_Y_number, 2, function(col) data_Y[col])

for (kk in 1:loop) {
  ##############initialize the model coefficients
  
  
  data_Y=as.numeric(data_Y_boot[,kk])
  Z=Z_orin[data_Y_number[1:100,kk]]
  X=X_orin[data_Y_number[1:100,kk]]
  T=62
  
  L_6 <- 0
  p_6 <- rep(0,(T-1))
  z_6 <- rep(NA,2)
  
  mybeta=0.5
  mygama=0.5
  
  initialvalues <- c(mybeta, mygama)
  
  GINARlik=function(z_6){
    
    
    for(k in 1:(T-1)){
      minX <- ifelse(data_Y[k]<data_Y[k+1],data_Y[k],data_Y[k+1])
      for(i in 0:minX){
        p_6[k] <- p_6[k]+choose(data_Y[k],i)*((exp(z_6[1]*X[k+1])/(1+exp(z_6[1]*X[k+1])))^i)*((1-(exp(z_6[1]*X[k+1])/(1+exp(z_6[1]*X[k+1]))))^(data_Y[k]-i))*((1/(1+exp(z_6[2]*Z[k+1])))*((1-(1/(1+exp(z_6[2]*Z[k+1]))))^(data_Y[k+1]-i)))
      }
    }
    L_6 <- -sum(log(p_6))
    return(L_6)
  }
  
  cmleG<-suppressWarnings(optim(initialvalues, GINARlik, method="BFGS")$par)
  beta_init_hat <- cmleG[1]
  gama_init_hat <- cmleG[2]
  
  ##############initialize the value of F and Q - “sliding window” approach 
  width=62
  T=100
  
  
  beta_window_init <- rep(0,T-width+1)
  
  gama_window_init <- rep(0,T-width+1)
  
  
  
  for (j in 1:(T-width+1)){  
    L_6 <- 0
    p_6 <- rep(0,(width-1))
    z_6 <- rep(NA,2)
    Y_sliding = data_Y[j:(j+width-1)]
    X_sliding=X[(j+1):(j+width)]
    
    Z_sliding=Z[(j+1):(j+width)]
    
    Y_sliding <- as.numeric(Y_sliding)
    n <- length(Y_sliding)
    
    mybeta <- 0.5
    mygama <- 0.5
    
    
    initialvalues_w <- c(mybeta, mygama)
    
    
    GINARlik_window=function(z_6){
      
      for(k in 1:(n-1)){
        minX <- ifelse(Y_sliding[k]<Y_sliding[k+1],Y_sliding[k],Y_sliding[k+1])
        for(i in 0:minX){
          p_6[k] <- p_6[k]+choose(Y_sliding[k],i)*((exp(z_6[1]*X_sliding[k])/(1+exp(z_6[1]*X_sliding[k])))^i)*((1-(exp(z_6[1]*X_sliding[k])/(1+exp(z_6[1]*X_sliding[k]))))^(Y_sliding[k]-i))*((1/(1+exp(z_6[2]*Z_sliding[k])))*((1-(1/(1+exp(z_6[2]*Z_sliding[k]))))^(Y_sliding[k+1]-i)))
        }
      }
      L_6 <- -sum(log(p_6))
      return(L_6)
    }
    
    
    cmleG_window<-suppressWarnings(optim(initialvalues_w, GINARlik_window, method = "BFGS")$par)
    
    beta_window_init[j] <- cmleG_window[1]
    gama_window_init[j] <- cmleG_window[2]
    
    
  }
  
  ######################################state space model
  mm=200
  T=200
  
  beta0_Init <- data.frame(beta_window_init,gama_window_init)
  colnames(beta0_Init)=c("beta","gamma")
  
  beta0_hat <- array(0,dim = c(T,S)) 
  beta0_hat_c <- array(0,dim = c(T,S)) 
  beta0_hat_S <- array(0,dim = c(T,S))
  colnames(beta0_hat)=c("beta","gamma")   
  beta0_hat[1,] <- c(beta_init_hat,gama_init_hat)
  H <- matrix(0,T,S)
  K <- array(0,dim = c(T,S))
  R <- array(0,dim = c(T))
  J <- array(0,dim=c(S,S,T)) 
  I <- array(0,dim=c(S,S,2)) #iteration stop matrix
  P0 <- array(0,dim=c(S,S,T))###prediction covariance matrix
  P1 <- array(0,dim=c(S,S,T))###correction covariance matrix
  P2 <- array(0,dim=c(S,S,T))###smoothing covariance matrix
  P <- array(0,dim=c(S,S,T))###E step
  P12 <- array(0,dim=c(S,S,T))###E step
  EP12 <- array(0,dim=c(S,S,T))###E step
  
  
  alpha_hat <- rep(0,(T-1))
  phi_hat <- rep(0,(T-1))
  Cov0_matrix <- array(0,dim=c(S,S))
  
  
  if(kk==1){
    Var0 <- VAR(data.frame(beta0_Init[,1:2]), p = 1, type = "none")
    
    F0 <- matrix(c(Var0$varresult$beta$coefficients,Var0$varresult$gamma$coefficients),S,S,byrow = T)
    Q0 <-summary(Var0)$covres
    F0=F0-matrix(c(0,F0[2,1],F0[1,2],0),2,2)
    Q0=Q0-matrix(c(0,Q0[2,1],Q0[1,2],0),2,2)
  }
  
  Cov0_matrix <- cov(beta0_Init)
  P0[,,1] <- F0%*%Cov0_matrix%*%t(F0)+Q0
  
  
  
  
  T=100
  
  loop_em=20###EM
  for (l in 1:loop_em) {
    A=F0
    AA=Q0
    ######Kalman Filter
    for (t in 1:(T-1)) {
      ###############correction step
      H[t,] <- rbind(data_Y[t]*(exp(beta0_hat[t,1]*X[(t+1)]))*X[(t+1)]/(1+exp(beta0_hat[t,1]*X[(t+1)]))^2,
                     Z[(t+1)]*exp(beta0_hat[t,2]*Z[(t+1)]))
      
      R[t] <- (1-(1/(1+exp(beta0_hat[t,2]*Z[(t+1)]))))/
        (((1/(1+exp(beta0_hat[t,2]*Z[(t+1)])))^2)*(1-(exp(beta0_hat[t,1]*X[(t+1)])/(1+exp(beta0_hat[t,1]*X[(t+1)])))))
      K[t,] <- P0[,,t]%*%H[t,]%*%solve(t(H[t,])%*%P0[,,t]%*%H[t,]+R[t]) 
      beta0_hat_c[t,] <- beta0_hat[t,]+K[t,]*(data_Y[t+1]-((exp(beta0_hat[t,1]*X[(t+1)])/(1+exp(beta0_hat[t,1]*X[(t+1)])))*
                                                             data_Y[t]+exp(beta0_hat[t,2]*Z[(t+1)])))
      P1[,,t] <- (diag(S)-K[t,]%*%t(H[t,]))%*%P0[,,t]
      
      #############prediction step
      beta0_hat[(t+1),]=F0%*%beta0_hat_c[t,]
      P0[,,(t+1)] <- F0%*%P1[,,t]%*%t(F0)+Q0
    }
    ######Kalman smoothing(E step)
    beta0_hat_S[(T-1),]=beta0_hat_c[(T-1),]###sample T
    P2[,,(T-1)]=P1[,,(T-1)]
    
    for (t in (T-2):1) {
      J[,,t]=P1[,,t]%*%t(F0)%*%solve(P0[,,(t+1)])
      beta0_hat_S[t,]=beta0_hat_c[t,]+J[,,t]%*%(beta0_hat_S[(t+1),]-F0%*%beta0_hat_c[t,])
      P2[,,t]=P1[,,t]+J[,,t]%*%(P2[,,(t+1)]-P0[,,(t+1)])%*%t(J[,,t])
    }
    ######M step
    for (t in (T-1):1) {
      P[,,t]=P2[,,t]+beta0_hat_S[t,]%*%t(beta0_hat_S[t,])###corresponding P_t for t=T-1,...1
    }
    P12[,,(T-1)]=(diag(S)-K[(T-1),]%*%t(H[(T-1),]))%*%F0%*%P1[,,(T-2)]
    for (t in (T-2):2) {
      P12[,,t]=P1[,,t]%*%t(J[,,(t-1)])+J[,,t]%*%(t(P12[,,(t+1)])-F0%*%P1[,,t])%*%t(J[,,(t-1)])###V_t,t-1
    }
    for (t in (T-1):2) {
      EP12[,,t]=P12[,,t]+beta0_hat_S[t,]%*%t(beta0_hat_S[(t-1),])###P_t,t-1
    }
    for (t in 1:(T-1)) {
      alpha_hat[t]=exp(beta0_hat_S[t,1]*X[(t+1)])/(1+exp(beta0_hat_S[t,1]*X[(t+1)]))
      
    }
    for (t in 1:(T-1)) {
      phi_hat[t]=1/(1+exp(beta0_hat_S[t,2]*Z[(t+1)]))
      
    }
    
    F0=apply(EP12, MARGIN = c(1, 2), FUN = sum)%*%solve(apply(P[,,1:(T-2)], MARGIN = c(1, 2), FUN = sum))
    F0=F0-matrix(c(0,F0[2,1],F0[1,2],0),2,2)
    Q0=1/(T-2)*(apply(P[,,2:(T-1)], MARGIN = c(1, 2), FUN = sum)-F0%*%t(apply(EP12, MARGIN = c(1, 2), FUN = sum)))
    Q0=Q0-matrix(c(0,Q0[2,1],Q0[1,2],0),2,2)
    P0[,,1]=P[,,1]-beta0_hat_S[1,]%*%t(beta0_hat_S[1,])
    # Frobenius norm
    B=F0
    BB=Q0
    norm_diff_F0_u <- sqrt(sum((A - B)^2))
    norm_diff_Q0_u <- sqrt(sum((AA - BB)^2))
    
    if(max(abs(c(norm_diff_F0_u, norm_diff_Q0_u)))<10^-5){break}
    
    
    beta0_hat[1,]=beta0_hat_S[1,]
    
    
  }
  
  
  
  
  
  FF00[,,kk]=F0
  QQ00[,,kk]=Q0
  beta_test_init[,,kk]=beta0_hat_S[1,]
  
  
}


F0=apply(FF00, MARGIN = c(1, 2), FUN = mean)
Q0=apply(QQ00, MARGIN = c(1, 2), FUN = mean)
beta0_hat[1,]=apply(beta_test_init, MARGIN = c(1, 2), FUN = mean)

X=X_orin
Z=Z_orin

for (t in 1:199) {
  ###############correction step
  H[t,] <- rbind(data_Y_orin[t]*(exp(beta0_hat[t,1]*X[(t+1)]))*X[(t+1)]/(1+exp(beta0_hat[t,1]*X[(t+1)]))^2,
                 Z[(t+1)]*exp(beta0_hat[t,2]*Z[(t+1)]))
  
  R[t] <- (1-(1/(1+exp(beta0_hat[t,2]*Z[(t+1)]))))/
    (((1/(1+exp(beta0_hat[t,2]*Z[(t+1)])))^2)*(1-(exp(beta0_hat[t,1]*X[(t+1)])/(1+exp(beta0_hat[t,1]*X[(t+1)])))))
  K[t,] <- P0[,,t]%*%H[t,]%*%solve(t(H[t,])%*%P0[,,t]%*%H[t,]+R[t]) 
  beta0_hat_c[t,] <- beta0_hat[t,]+K[t,]*(data_Y_orin[t+1]-((exp(beta0_hat[t,1]*X[(t+1)])/(1+exp(beta0_hat[t,1]*X[(t+1)])))*
                                                              data_Y_orin[t]+exp(beta0_hat[t,2]*Z[(t+1)])))
  P1[,,t] <- (diag(S)-K[t,]%*%t(H[t,]))%*%P0[,,t]
  
  #############prediction step
  beta0_hat[(t+1),]=F0%*%beta0_hat_c[t,]
  P0[,,(t+1)] <- F0%*%P1[,,t]%*%t(F0)+Q0
}


##################Phase-II
T=200
N=700
T1=N-T

theta=rbind(theta,array(0,dim = c((T1+1),S)))
alpha=rep(0,N)
phi=rep(0,N)

beta0_hat=rbind(beta0_hat,array(0,dim = c(T1,S)))
beta0_hat_c=rbind(beta0_hat_c,array(0,dim = c(T1,S)))

P0_expanded <- array(0, dim = c(S, S, N))
P0_expanded[, , 1:T] <- P0
P1_expanded <- array(0, dim = c(S, S, N))
P1_expanded[, , 1:T] <- P1
H=rbind(H,array(0,dim = c(T1,S)))
K=rbind(K,array(0,dim = c(T1,S)))
R=c(R,rep(0,T1))




############################Generate test sample 

e_control_limit=4.633
loop=2000
ss=1

rl_shift=rep(0,8)
for (delta in c(0, 0.1, 0.2, 0.4, 0.6, 0.8, 1, 1.2)) {
  rl=rep(0,loop)
  for (ll in 1:loop) {
    
    X[(T+1):N]=rnorm(T1,0.5,0.25)##covariate 
    Z[(T+1):N]=rnorm(T1,0.5,0.25)
    
    for (t in T:N) {
      
      alpha[t]=exp(theta[t,1]*X[t])/(1+exp(theta[t,1]*X[t]))
      phi[t]=1/(1+exp(theta[t,2]*Z[t]))
      theta[(t+1),]=F0_s%*%theta[t,]+mvrnorm(1,epsi_mu,Q0_s)+c(delta,0.04)
    }
    data_Y_ex=c()
    Y=data_Y_orin[T]
    for(t in (T+1):N) {
      Y <- rbinom(1,Y,alpha[t])+rgeom(1,phi[t])
      data_Y_ex <- c(data_Y_ex,Y)
    }
    data_Y[(T+1):N]=data_Y_ex
    data_Y[1:T]=data_Y_orin[1:T]
    
    ########################################model_based
    
    for(t in T:(N-1)){
      
      H[t,] <- rbind(data_Y[t]*(exp(beta0_hat[t,1]*X[(t+1)]))*X[(t+1)]/(1+exp(beta0_hat[t,1]*X[(t+1)]))^2,
                     Z[(t+1)]*exp(beta0_hat[t,2]*Z[(t+1)]))
      
      R[t] <- (1-(1/(1+exp(beta0_hat[t,2]*Z[(t+1)]))))/
        (((1/(1+exp(beta0_hat[t,2]*Z[(t+1)])))^2)*(1-(exp(beta0_hat[t,1]*X[(t+1)])/(1+exp(beta0_hat[t,1]*X[(t+1)])))))
      K[t,] <- P0_expanded[,,t]%*%H[t,]%*%solve(t(H[t,])%*%P0_expanded[,,t]%*%H[t,]+R[t]) 
      beta0_hat_c[t,] <- beta0_hat[t,]+K[t,]*(data_Y[t+1]-((exp(beta0_hat[t,1]*X[(t+1)])/(1+exp(beta0_hat[t,1]*X[(t+1)])))*
                                                             data_Y[t]+exp(beta0_hat[t,2]*Z[(t+1)])))
      P1_expanded[,,t] <- (diag(S)-K[t,]%*%t(H[t,]))%*%P0_expanded[,,t]
      
      #############prediction step
      beta0_hat[(t+1),]=F0%*%beta0_hat_c[t,]
      P0_expanded[,,(t+1)] <- F0%*%P1_expanded[,,t]%*%t(F0)+Q0
      
      
    }
    beta0_hat_c[N,]=beta0_hat[N,]
    
    ##############################control chart
    alpha_hat=rep(0,N)
    for (t in T:(N-1)) {
      
      alpha_hat[t]=exp(beta0_hat_c[t,1]*X[(t+1)])/(1+exp(beta0_hat_c[t,1]*X[(t+1)]))
      
    }
    
    phi_hat=rep(0,N)
    for (t in T:(N-1)) {
      
      phi_hat[t]=1/(1+exp(beta0_hat_c[t,2]*Z[(t+1)]))
      
    }
    
    
    residual=rep(0,T1)
    for (t in T:(N-1)) {
      
      residual[t-T+1]=(data_Y[(t+1)]-(alpha_hat[t]*data_Y[t]+(1-phi_hat[t])/phi_hat[t]))/
        sqrt(alpha_hat[t]*(1-alpha_hat[t])*data_Y[t]+(1-phi_hat[t])/(phi_hat[t]^2))
      
    }
    
    
    
    if(min(which(residual>e_control_limit)) < Inf){
      rl[ll]=min(which(residual>e_control_limit))
    }
    if(min(which(residual>e_control_limit))==Inf){
      rl[ll]=T1
    }
    print(c(ll,rl[ll]))
  }
  median(rl)
  rl_shift[ss]=median(rl)
  ss=ss+1
}
rl_shift

deltaw=rep(0.04,8)
deltaw1=c(0, 0.1, 0.2, 0.4, 0.6, 0.8, 1, 1.2)

rl_result=data.frame(T,e_control_limit,0.5,0.8,0.05,0.05,beta_init,gamma_init,deltaw1,deltaw,rl_shift)
colnames(rl_result)=c("reference_sample_size","UCL","F0[1,1]","F0[2,2]","Q0[1,1]","Q0[2,2]","beta0","gamma0","alpha_shift","phi_shift","MRL")

write.csv(rl_result,file = "E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\SDC-INAR(1)-G-R\\Scenario_A\\Phase-II_Case-IV.csv")



