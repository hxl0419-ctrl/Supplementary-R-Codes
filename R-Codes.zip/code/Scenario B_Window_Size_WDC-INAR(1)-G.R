library("vars")
library("MASS")
library("stats4")
library("splines")
library("VGAM")
library("tcltk")
library("gamlss")
library("HMMpa")
library("tseries")
library("forecast")

###########Scenario B
set.seed(666)
T <- 200
S <- 2
loop=200


X=rnorm(T,0.5,0.25)##covariate 
Z=rnorm(T,0.5,0.25)
X_orin=X
Z_orin=Z
##########model parameter initial setting ################### 
m=1
beta_init=0.1
gamma_init=0.2
alpha=rep(0,T)
phi=rep(0,T)

for (t in 1:T) {
  
  alpha[t]=exp(beta_init*X[t])/(1+exp(beta_init*X[t]))
  phi[t]=1/(1+exp(gamma_init*Z[t]))
}

#generate INAR random number
data_Y=c()
Y <-3#####given initial observed value
for(t in 1:T) {
  
  Y <- rbinom(1,Y,alpha[t])+rgeom(1,phi[t])
  data_Y <- c(data_Y,Y)
}
data_Y_orin=data_Y
###revised moving block bootstrap (MBB) approach
data_Y_number=tsbootstrap(1:200,nb=199,b=100,type = "block")
data_Y_number=cbind(1:200,data_Y_number)
data_Y_boot <- apply(data_Y_number, 2, function(col) data_Y[col])

dif=rep(0,100)

for (kkk in 81:88) {
  
  FF00=array(0,dim=c(S,S,loop))
  QQ00=array(0,dim=c(S,S,loop))
  beta_init_hat=rep(0,loop)
  gamma_init_hat=rep(0,loop)
  
  
  for (kk in 1:loop) {
    ##############initialize the model coefficients
    
    
    data_Y=as.numeric(data_Y_boot[,kk])
    Z=Z_orin[data_Y_number[1:100,kk]]
    X=X_orin[data_Y_number[1:100,kk]]
    T=kkk
    
    L_6 <- 0
    p_6 <- rep(0,(T-1))
    z_6 <- rep(NA,2)
    
    mybeta=0.5
    mygama=0.5
    
    initialvalues <- c(mybeta, mygama)
    
    GINARlik=function(z_6){
      
      
      for(k in 1:(T-1)){
        minX <- ifelse(data_Y[k]<data_Y[k+1],data_Y[k],data_Y[k+1])
        for(i in 0:minX){
          p_6[k] <- p_6[k]+choose(data_Y[k],i)*((exp(z_6[1]*X[k+1])/(1+exp(z_6[1]*X[k+1])))^i)*((1-(exp(z_6[1]*X[k+1])/(1+exp(z_6[1]*X[k+1]))))^(data_Y[k]-i))*((1/(1+exp(z_6[2]*Z[k+1])))*((1-(1/(1+exp(z_6[2]*Z[k+1]))))^(data_Y[k+1]-i)))
        }
      }
      L_6 <- -sum(log(p_6))
      return(L_6)
    }
    
    cmleG<-suppressWarnings(optim(initialvalues, GINARlik, method="BFGS")$par)
    beta_init_hat[kk] <- cmleG[1]
    gamma_init_hat[kk] <- cmleG[2]
    
    ##############initialize the value of F and Q - “sliding window” approach 
    width=kkk
    T=100
    
    
    beta_window_init <- rep(0,T-width+1)
    
    gama_window_init <- rep(0,T-width+1)
    
    
    
    for (j in 1:(T-width+1)){  
      L_6 <- 0
      p_6 <- rep(0,(width-1))
      z_6 <- rep(NA,2)
      Y_sliding = data_Y[j:(j+width-1)]
      X_sliding=X[(j+1):(j+width)]
      
      Z_sliding=Z[(j+1):(j+width)]
      
      Y_sliding <- as.numeric(Y_sliding)
      n <- length(Y_sliding)
      
      mybeta <- 0.5
      mygama <- 0.5
      
      
      initialvalues_w <- c(mybeta, mygama)
      
      
      GINARlik_window=function(z_6){
        
        for(k in 1:(n-1)){
          minX <- ifelse(Y_sliding[k]<Y_sliding[k+1],Y_sliding[k],Y_sliding[k+1])
          for(i in 0:minX){
            p_6[k] <- p_6[k]+choose(Y_sliding[k],i)*((exp(z_6[1]*X_sliding[k])/(1+exp(z_6[1]*X_sliding[k])))^i)*((1-(exp(z_6[1]*X_sliding[k])/(1+exp(z_6[1]*X_sliding[k]))))^(Y_sliding[k]-i))*((1/(1+exp(z_6[2]*Z_sliding[k])))*((1-(1/(1+exp(z_6[2]*Z_sliding[k]))))^(Y_sliding[k+1]-i)))
          }
        }
        L_6 <- -sum(log(p_6))
        return(L_6)
      }
      
      
      cmleG_window<-suppressWarnings(optim(initialvalues_w, GINARlik_window, method = "BFGS")$par)
      
      beta_window_init[j] <- cmleG_window[1]
      gama_window_init[j] <- cmleG_window[2]
      
      
    }
    
    ######################################state space model
    
    
    beta0_Init <- data.frame(beta_window_init,gama_window_init)
    colnames(beta0_Init)=c("beta","gamma")
    
    
    Var0 <- VAR(data.frame(beta0_Init[,1:2]), p = 1, type = "none")
    
    F0 <- matrix(c(Var0$varresult$beta$coefficients,Var0$varresult$gamma$coefficients),S,S,byrow = T)
    Q0 <-summary(Var0)$covres
    F0=F0-matrix(c(0,F0[2,1],F0[1,2],0),2,2)
    Q0=Q0-matrix(c(0,Q0[2,1],Q0[1,2],0),2,2)
    FF00[,,kk]=F0
    QQ00[,,kk]=Q0
    
  }
  
  
  
  
  F0=apply(FF00, MARGIN = c(1, 2), FUN = mean)
  Q0=apply(QQ00, MARGIN = c(1, 2), FUN = mean)
  
  
  T=200
  H <- matrix(0,T,S)
  K <- array(0,dim = c(T,S))
  R <- array(0,dim = c(T))
  P0 <- array(0,dim=c(S,S,T))###prediction covariance matrix
  P1 <- array(0,dim=c(S,S,T))###correction covariance matrix
  J <- array(0,dim=c(S,S,T)) 
  beta0_hat <- array(0,dim = c(T,S))
  beta0_hat_S <- array(0,dim = c(T,S))
  beta0_hat_c <- array(0,dim = c(T,S))
  beta0_hat[1,]=c(mean(beta_init_hat),mean(gamma_init_hat))
  P0[,,1] <- cov(cbind(beta_init_hat,gamma_init_hat))
  
  X=X_orin
  Z=Z_orin
  
  for (t in 1:199) {
    ###############correction step
    H[t,] <- rbind(data_Y_orin[t]*(exp(beta0_hat[t,1]*X[(t+1)]))*X[(t+1)]/(1+exp(beta0_hat[t,1]*X[(t+1)]))^2,
                   Z[(t+1)]*exp(beta0_hat[t,2]*Z[(t+1)]))
    
    R[t] <- (1-(1/(1+exp(beta0_hat[t,2]*Z[(t+1)]))))/
      (((1/(1+exp(beta0_hat[t,2]*Z[(t+1)])))^2)*(1-(exp(beta0_hat[t,1]*X[(t+1)])/(1+exp(beta0_hat[t,1]*X[(t+1)])))))
    K[t,] <- P0[,,t]%*%H[t,]%*%solve(t(H[t,])%*%P0[,,t]%*%H[t,]+R[t]) 
    beta0_hat_c[t,] <- beta0_hat[t,]+K[t,]*(data_Y_orin[t+1]-((exp(beta0_hat[t,1]*X[(t+1)])/(1+exp(beta0_hat[t,1]*X[(t+1)])))*
                                                                data_Y_orin[t]+exp(beta0_hat[t,2]*Z[(t+1)])))
    P1[,,t] <- (diag(S)-K[t,]%*%t(H[t,]))%*%P0[,,t]
    
    #############prediction step
    beta0_hat[(t+1),]=F0%*%beta0_hat_c[t,]
    P0[,,(t+1)] <- F0%*%P1[,,t]%*%t(F0)+Q0
  }
  
  T=200
  ######Kalman smoothing
  beta0_hat_S[(T-1),]=beta0_hat_c[(T-1),]###sample T
  
  
  for (t in (T-2):1) {
    J[,,t]=P1[,,t]%*%t(F0)%*%solve(P0[,,(t+1)])
    beta0_hat_S[t,]=beta0_hat_c[t,]+J[,,t]%*%(beta0_hat_S[(t+1),]-F0%*%beta0_hat_c[t,])
    
  }
  
  alpha_hat=rep(0,T)
  for (t in 1:T) {
    
    alpha_hat[t]=exp(beta0_hat_S[t,1]*X[(t+1)])/(1+exp(beta0_hat_S[t,1]*X[(t+1)]))
    
  }
  
  phi_hat=rep(0,T)
  for (t in 1:T) {
    
    phi_hat[t]=1/(1+exp(beta0_hat_S[t,2]*Z[(t+1)]))
    
  }
  
  dif[kkk]=mean((data_Y_orin[2:T]-(alpha_hat[1:(T-1)]*data_Y_orin[1:(T-1)]+(1-phi_hat[1:(T-1)])/phi_hat[1:(T-1)]))^2)
  print(dif[kkk])
  write.table(cbind(kkk,dif[kkk]),file = "E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\WDC-INAR(1)-G\\Scenario_B\\Window_Size.csv",sep = ",", row.names = FALSE, col.names = FALSE,append = TRUE)
  
}

which(dif==min(dif[c(11:88)]))
