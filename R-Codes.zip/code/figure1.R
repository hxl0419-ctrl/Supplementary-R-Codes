library(ggplot2)
library(scales)
library(gridExtra)
library(ggfortify)
library(grid)

jpeg(
  filename = "G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\figure\\Figure_1.jpeg",
  width = 3000, 
  height = 2000, 
  res = 300, 
  quality = 100
)

data_count <- read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\data\\freq_brake_noise_month_201505_202312.csv", header = TRUE)


df <- data.frame(
  date_x = seq(as.Date('2015/5/1'), as.Date('2023/12/31'), by = "month"),
  value = data_count$MF
)

# Phase-I data (2015-05 to 2020-04)
phase_i_data <- subset(df, date_x <= as.Date("2020-04-01"))


time_plot <- ggplot(df, aes(x = date_x, y = value)) +
  geom_line(color = "black") +
  geom_point(size = 1, color = "black") +
  geom_vline(
    xintercept = as.numeric(as.Date('2020-04-01')), 
    color = "black", 
    linetype = "dashed", 
    linewidth = 0.5
  ) +
  labs(x = "Date (year/month)", y = "Complaint Frequency") +
  annotate("text", x = as.Date('2018-01-01'), y = 20, 
           label = "Phase-I", hjust = 0, size = 4) +
  annotate("text", x = as.Date('2021-12-01'), y = 20, 
           label = "Phase-II", hjust = 0, size = 4) +
  theme_classic() + 
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, color = "black"),
    axis.text.y = element_text(color = "black"),
    axis.line = element_line(color = "black"),
    axis.ticks = element_line(color = "black")
  ) +
  scale_x_date(
    breaks = seq(as.Date("2015-05-01"), as.Date("2023-12-31"), by = "6 months"),
    labels = date_format("%Y/%m"),
    limits = c(as.Date("2015-05-01"), as.Date("2023-12-31"))  
  )


time_with_caption <- arrangeGrob(
  time_plot,
  bottom = textGrob(
    "(a) The monthly frequency of brake abnormal noise complaints (2015–2023).",
    x = 0.5, 
    hjust = 0.5, 
    gp = gpar(fontsize = 11, fontface = "plain")
  )
)


plot_black_acf <- function(acf_obj, title) {
  autoplot(acf_obj, colour = "black", size = 1) +
    geom_hline(yintercept = 0, color = "black", linewidth = 0.5) +  
    labs(title = title, x = "Lag", y = "ACF") +  
    theme_classic() +
    theme(
      plot.title = element_text(color = "black"),
      axis.text = element_text(color = "black"),
      axis.line = element_line(color = "black")
    )
}

plot_black_pacf <- function(pacf_obj, title) {
  autoplot(pacf_obj, colour = "black", size = 1) +
    geom_hline(yintercept = 0, color = "black", linewidth = 0.5) +  
    labs(title = title, x = "Lag", y = "PACF") +  
    theme_classic() +
    theme(
      plot.title = element_text(color = "black"),
      axis.text = element_text(color = "black"),
      axis.line = element_line(color = "black")
    )
}

# ACF/PACF
acf_data <- stats::acf(phase_i_data$value, plot = FALSE)
pacf_data <- stats::pacf(phase_i_data$value, plot = FALSE)

 
acf_plot <- plot_black_acf(acf_data, "ACF (Phase-I Data)")
pacf_plot <- plot_black_pacf(pacf_data, "PACF (Phase-I Data)")


acf_pacf_combined <- grid.arrange(acf_plot, pacf_plot, ncol = 2)


acf_pacf_with_caption <- arrangeGrob(
  acf_pacf_combined,
  bottom = textGrob(
    "(b) Sample ACF and PACF plot of Phase-I data.",
    x = 0.5, 
    hjust = 0.5, 
    gp = gpar(fontsize = 11, fontface = "plain")
  )
)


combined_plot <- grid.arrange(
  time_with_caption,
  acf_pacf_with_caption,
  nrow = 2,
  heights = c(2, 1)
)


print(combined_plot)
dev.off()