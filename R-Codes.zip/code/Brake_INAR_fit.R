library("vars")
library("MASS")
library("stats4")
library("splines")
library("VGAM")
library("tcltk")
library("gamlss")
library("HMMpa")
library("tseries")
library("forecast")
library("dfphase1")



############################
set.seed(1)

data_count <- read.csv("E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\data\\freq_brake_noise_month_201505_202312.csv", header = TRUE)

data1=data_count$MF[1:60]

acf(data1)
pacf(data1)
Box.test(data1,lag=1)
adf.test(data1)


X <- as.numeric(data1)
n <- length(X)
maxval <- max(X)

############################


L <- L_1 <- L_2 <- L_3 <- L_4 <- L_5 <- L_6 <- L_7 <- L_8 <- 0
p <- p_1 <- p_2 <- p_3 <- p_4 <- p_5 <- p_6 <- p_7 <- p_8 <- rep(0,(n-1))
Z <- z_1 <- z_2 <- z_3 <- z_4 <- z_5 <- z_6 <- z_7 <- z_8 <- rep(NA,1,3)

barX <- mean(X)
alphayw <- acf(X, plot=FALSE)[[1]][2]
#################################################
##################INAR(1)_Poisson innovations
muyw <- barX
lamyw <- muyw*(1-alphayw)
###________CMLE
initialvalues_1 <- c(alphayw, lamyw)

PINARlik=function(z_1){
  
  for(k in 1:(n-1)){
    minX <- ifelse(X[k]<X[k+1],X[k],X[k+1])
    for(i in 0:minX){
      p_1[k] <- p_1[k]+choose(X[k],i)*(z_1[1]^i)*((1-z_1[1])^(X[k]-i))*(((z_1[2]))^(X[k+1]-i))*(exp(-z_1[2])/(factorial(X[k+1]-i)))
    }
  }
  L_1 <- -sum(log(p_1))
  return(L_1)
}

A_1 <- c(0.001,0.001)
B_1 <- c(0.999,Inf)
cmleP<-optim(initialvalues_1, PINARlik, method = "L-BFGS-B", lower = A_1, upper = B_1, control=list(ndeps=c(1e-4,1e-4)), hessian=TRUE)$par


AICP <- 2*2+2*PINARlik(cmleP)
BICP <- 2*log(n)+2*PINARlik(cmleP)
HQCP <- 2*2*log(log(n))+2*PINARlik(cmleP)
CAICP <- 2*(log(n)+1)+2*PINARlik(cmleP)




###########################################################################
##################INAR(1)_zero-inflated Poisson innovations
muyw <- barX
rhoyw <- length(X[X=0])/n-exp(-muyw)
lamyw4 <- muyw*(1-alphayw)/(1-rhoyw)
###________CMLE
initialvalues_4 <- c(alphayw, lamyw4, rhoyw)


ZIPINARlik=function(z_4){
  
  for(k in 1:(n-1)){
    minX <- ifelse(X[k]<X[k+1],X[k],X[k+1])
    for(i in 0:minX){
      if(X[k+1]-i==0){
        p_4[k] <- p_4[k]+choose(X[k],i)*(z_4[1]^i)*((1-z_4[1])^(X[k]-i))*(z_4[3]+(1-z_4[3])*(((z_4[2]))^(X[k+1]-i))*(exp(-z_4[2])/(factorial(X[k+1]-i))))
      }else{
        p_4[k] <- p_4[k]+choose(X[k],i)*(z_4[1]^i)*((1-z_4[1])^(X[k]-i))*((1-z_4[3])*(((z_4[2]))^(X[k+1]-i))*(exp(-z_4[2])/(factorial(X[k+1]-i))))
      }
    }
  }
  L_4 <- -sum(log(p_4))
  return(L_4)
}

A_4 <- c(0.001,0.001,0.001)
B_4 <- c(0.999,Inf,0.999)
cmleZIP<-optim(initialvalues_4, ZIPINARlik, method = "L-BFGS-B", lower = A_4, upper = B_4, control=list(ndeps=c(1e-4,1e-4,1e-4)), hessian=TRUE)$par


AICZIP <- 2*3+2*ZIPINARlik(cmleZIP)
BICZIP <- 3*log(n)+2*ZIPINARlik(cmleZIP)
HQCZIP <- 2*3*log(log(n))++2*ZIPINARlik(cmleZIP)
CAICZIP <- 3*(log(n)+1)+2*ZIPINARlik(cmleZIP)


##############################INARDP
## Double Poisson density function
qDPO1 <- function (p, mu = 1, phi = 1, lower.tail = TRUE, log.p = FALSE,
                   max.value = 10000)
{
  
  sigma <- 1/phi
  if (log.p == TRUE)
    p <- exp(p)
  else p <- p
  if (lower.tail == TRUE)
    p <- p
  else p <- 1 - p
  ly <- length(p)
  QQQ <- rep(0, ly)
  nsigma <- rep(sigma, length = ly)
  nmu <- rep(mu, length = ly)
  for (i in seq(along = p)) {
    cumpro <- 0
    if (p[i] + 1e-09 >= 1)
      QQQ[i] <- Inf
    else {
      for (j in seq(from = 0, to = max.value)) {
        cumpro <- pDPO(j, mu = nmu[i], sigma = nsigma[i],log.p = FALSE)
        QQQ[i] <- j
        if (p[i] <= cumpro)
          break
      }
    }
  }
  QQQ
}

dDPO1 <- function(x, mu = 1, phi = 1, log = FALSE)
{
  sigma <- 1/phi
  ly <- max(length(x), length(mu), length(sigma))
  x <- rep(x, length = ly)
  sigma <- rep(sigma, length = ly)
  mu <- rep(mu, length = ly)
  maxV <- max(max(x) * 3, 500)
  y <- 0:maxV
  logofx <- ifelse(x == 0, 1, log(x))
  lh <- -0.5 * log(sigma) - (mu/sigma) - lgamma(x + 1) + x *
    logofx - x + (x * log(mu))/sigma + x/sigma - (x * logofx)/sigma +
    get_C(x, mu, sigma)
  if (log == FALSE)
    fy <- exp(lh)
  else fy <- lh
  fy
}

# tp
tpDP<-function(k,l,theta1,theta2,alpha){
  tp <- 0
  for (j in c(0:min(k,l))){
    tp <- tp + dbinom(j, l, alpha)*dDPO1(k-j, mu=theta1, phi = theta2)
  }
  tp
}

# Log-likehood of INARGPIG(1) model
DPINARlik <- function(par,data){
  T <- length(X)
  value <-0
  theta1 <- par[1]
  theta2 <- par[2]
  alpha <- par[3]
  for(t in c(2:T)){
    if(is.finite(log(tpDP(data[t],data[t-1],theta1,theta2,alpha)))){
      value <- value-log(tpDP(data[t],data[t-1],theta1,theta2,alpha))
    }
    else{
      value <- value-1
    }
  }
  value
}
#initial value
theta1_1 <- (1-alphayw)*barX
theta2_1 <- barX/(var(X)*(1+alphayw)-barX*alphayw)
alpha_1 <- alphayw

cmleDP <- optim(c(theta1_1,theta2_1,alpha_1),DPINARlik, method = "L-BFGS-B",
                lower=c(0.0001,0.0001,0.0001),upper=c(9999,9999,0.9999),data=X,control=list(ndeps=c(1e-4,1e-4,1e-4)), hessian=TRUE)

theta1estm1 <- cmleDP$par[[1]]
theta2estm1 <- cmleDP$par[[2]]
alphaestm1 <- cmleDP$par[[3]]

neglmax <- cmleDP$value


AICDP <- 2*neglmax+3*2
BICDP <- 2*neglmax+log(n)*3
HQCDP <- 2*neglmax+2*3*(log(log(n)))
CAICDP <- 2*neglmax+(log(n)+1)*3

#############################INARGP
# tp
tpGP<-function(k,l,theta1,theta2,alpha){
  tp <- 0
  for (j in c(0:min(k,l))){
    tp <- tp+dbinom(j, l, alpha)*dgenpois(k-j, lambda1=theta1, lambda2 = theta2)
  }
  tp
}

# Log-likehood of INARGPIG(1) model
GPINARlik <- function(par,data){
  T <- length(data)
  value <-0
  theta1<-par[1]
  theta2<-par[2]
  alpha <- par[3]
  for(t in c(2:T)){
    if(is.finite(log(tpGP(data[t],data[t-1],theta1,theta2,alpha)))){
      value <- value-log(tpGP(data[t],data[t-1],theta1,theta2,alpha))
    }
    else{
      value <- value-1
    }
  }
  value
}

#initial value
FIx <- var(X)/barX

theta2_1 <- (alphayw*FIx-sqrt(alphayw*FIx-alphayw+FIx)-alphayw+FIx)/(alphayw*FIx-alphayw+FIx)
theta1_1 <- (1-alphayw)*(1-theta2_1)*barX
alpha_1 <- alphayw
cmleGP <- optim(c(theta1_1,theta2_1,alpha_1),GPINARlik, method = "L-BFGS-B",
                lower=c(0.0001,0.0001,0.0001),upper=c(9999,9999,0.9999),data=X,control=list(ndeps=c(1e-4,1e-4,1e-4)), hessian=TRUE)$par


#AIC and BIC:
AICGP <- 2*GPINARlik(cmleGP,X)+2*3
BICGP <- 2*GPINARlik(cmleGP,X)+3*log(n)
HQCGP <- 2*GPINARlik(cmleGP,X)+2*3*log(log(n))
CAICGP <- 2*GPINARlik(cmleGP,X)+3*(log(n)+1)

#############################NBINAR
varX <- (n-1)/n*var(X)
pyw <- barX*(1-alphayw)/(varX*(1-alphayw^2)-barX*alphayw*(1-alphayw))
ryw <- barX*(1-alphayw)*pyw/(1-pyw)
###________CMLE
initialvalues_5 <- c(alphayw, ryw, pyw)

NBINARlik=function(z_5){
  
  for(k in 1:(n-1)){
    minX <- ifelse(X[k]<X[k+1],X[k],X[k+1])
    for(i in 0:minX){
      p_5[k] <- p_5[k]+choose(X[k],i)*(z_5[1]^i)*((1-z_5[1])^(X[k]-i))*(choose(z_5[2]+X[k+1]-i-1,X[k+1]-i)*(z_5[3]^z_5[2])*((1-z_5[3])^(X[k+1]-i)))
    }
  }
  L_5 <- -sum(log(p_5))
  return(L_5)
}

A_5 <- c(0.001,0.001,0.001)
B_5 <- c(0.999,Inf,0.999)
cmleNB<-optim(initialvalues_5, NBINARlik, method = "L-BFGS-B", lower = A_5, upper = B_5, control=list(ndeps=c(1e-4,1e-4,1e-4)), hessian=TRUE)$par

AICNB <- 2*3+2*NBINARlik(cmleNB)
BICNB <- 3*log(n)+2*NBINARlik(cmleNB)
HQCNB <- 2*3*log(log(n))++2*NBINARlik(cmleNB)
CAICNB <- 3*(log(n)+1)+2*NBINARlik(cmleNB)

#######################################################GINAR
pgyw <- 1/(1+barX*(1-alphayw))
###________CMLE
initialvalues_6 <- c(alphayw, pgyw)

GINARlik=function(z_6){
  
  for(k in 1:(n-1)){
    minX <- ifelse(X[k]<X[k+1],X[k],X[k+1])
    for(i in 0:minX){
      p_6[k] <- p_6[k]+choose(X[k],i)*(z_6[1]^i)*((1-z_6[1])^(X[k]-i))*(z_6[2]*((1-z_6[2])^(X[k+1]-i)))
    }
  }
  L_6 <- -sum(log(p_6))
  return(L_6)
}

A_6 <- c(0.001,0.001)
B_6 <- c(0.999,0.999)
cmleG<-optim(initialvalues_6, GINARlik, method = "L-BFGS-B", lower = A_6, upper = B_6, control=list(ndeps=c(1e-4,1e-4)), hessian=TRUE)$par



AICG <- 2*2+2*GINARlik(cmleG)
BICG <- 2*log(n)+2*GINARlik(cmleG)
HQCG <- 2*2*log(log(n))+2*GINARlik(cmleG)
CAICG <- 2*(log(n)+1)+2*GINARlik(cmleG)


###########################################################################
##################INAR(1)_zero-inflated NB innovations
rhoyw7 <- 0.5
pyw7 <- 0.5
ryw7 <- (barX*(1-alphayw)*pyw7)/((1-rhoyw7)*(1-pyw7))
###________CMLE
initialvalues_7 <- c(alphayw, ryw7, pyw7, rhoyw7)


ZINBINARlik=function(z_7){
  
  for(k in 1:(n-1)){
    minX <- ifelse(X[k]<X[k+1],X[k],X[k+1])
    for(i in 0:minX){
      if(X[k+1]-i==0){
        p_7[k] <- p_7[k]+choose(X[k],i)*(z_7[1]^i)*((1-z_7[1])^(X[k]-i))*(z_7[4]+(1-z_7[4])*((z_7[3])^(z_7[2])))
      }else{
        p_7[k] <- p_7[k]+choose(X[k],i)*(z_7[1]^i)*((1-z_7[1])^(X[k]-i))*((1-z_7[4])*(choose(z_7[2]+X[k+1]-i-1,X[k+1]-i)*(z_7[3]^z_7[2])*((1-z_7[3])^(X[k+1]-i))))
      }
    }
  }
  L_7 <- -sum(log(p_7))
  return(L_7)
}

A_7 <- c(0.001,0.001,0.001,0.001)
B_7 <- c(0.999,Inf,0.999,0.999)
cmleZINB<-optim(initialvalues_7, ZINBINARlik, method = "L-BFGS-B", lower = A_7, upper = B_7, control=list(ndeps=c(1e-4,1e-4,1e-4,1e-4)), hessian=TRUE)$par

AICZINB <- 2*4+2*ZINBINARlik(cmleZINB)
BICZINB <- 4*log(n)+2*ZINBINARlik(cmleZINB)
HQCZINB <- 2*4*log(log(n))++2*ZINBINARlik(cmleZINB)
CAICZINB <- 4*(log(n)+1)+2*ZINBINARlik(cmleZINB)

###########################################################################
##################INAR(1)_zero-inflated GE innovations
pgyw8 <- 0.3
rhoyw8 <- length(X[X=0])/n-pgyw8
###________CMLE
initialvalues_8 <- c(alphayw, pgyw8, rhoyw8)


ZIGINARlik=function(z_8){
  
  for(k in 1:(n-1)){
    minX <- ifelse(X[k]<X[k+1],X[k],X[k+1])
    for(i in 0:minX){
      if(X[k+1]-i==0){
        p_8[k] <- p_8[k]+choose(X[k],i)*(z_8[1]^i)*((1-z_8[1])^(X[k]-i))*(z_8[3]+(1-z_8[3])*z_8[2])
      }else{
        p_8[k] <- p_8[k]+choose(X[k],i)*(z_8[1]^i)*((1-z_8[1])^(X[k]-i))*((1-z_8[3])*z_8[2]*((1-z_8[2])^(X[k+1]-i)))
      }
    }
  }
  L_8 <- -sum(log(p_8))
  return(L_8)
}

A_8 <- c(0.001,0.001,0.001)
B_8 <- c(0.999,0.999,0.999)
cmleZIG<-optim(initialvalues_8, ZIGINARlik, method = "L-BFGS-B", lower = A_8, upper = B_8, control=list(ndeps=c(1e-4,1e-4,1e-4)), hessian=TRUE)$par


AICZIG <- 2*3+2*ZIGINARlik(cmleZIG)
BICZIG <- 3*log(n)+2*ZIGINARlik(cmleZIG)
HQCZIG <- 2*3*log(log(n))++2*ZIGINARlik(cmleZIG)
CAICZIG <- 3*(log(n)+1)+2*ZIGINARlik(cmleZIG)



###############################################################
parameters_result=c(cmleP,cmleDP$par,cmleGP,cmleZIP,cmleNB,cmleG,cmleZINB,cmleZIG)



AIC=c(AICP,AICDP,AICGP,AICZIP,AICNB,AICG,AICZINB,AICZIG)
BIC=c(BICP,BICDP,BICGP,BICZIP,BICNB,BICG,BICZINB,BICZIG)
HQIC=c(HQCP,HQCDP,HQCGP,HQCZIP,HQCNB,HQCG,HQCZINB,HQCZIG)
CAIC=c(CAICP,CAICDP,CAICGP,CAICZIP,CAICNB,CAICG,CAICZINB,CAICZIG)

result=rbind(AIC,BIC,HQIC,CAIC)

parameters_result
result
print(result)
colnames(result)=c("Poisson","Double Poisson","Generalized Poisson","Zero-Inflated Poisson","Negative Binomial","Geometric","Zero-Inflated Negative Binomial","Zero-Inflated Geometric")
write.csv(result,file = "E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\Brake_INAR_fit.csv")
