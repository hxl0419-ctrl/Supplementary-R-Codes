library("vars")
library("MASS")
library("stats4")
library("splines")
library("VGAM")
library("tcltk")
library("gamlss")
library("HMMpa")
library("tseries")
library("forecast")

###########Scenario A
set.seed(666)
T <- 200
S <- 2
loop=200


X=rnorm(T,0.5,0.25)##covariate 
Z=rnorm(T,0.5,0.25)
X_orin=X
Z_orin=Z
##########model parameter initial setting ################### 
m=1
beta_init=0.1
gamma_init=0.2
theta_init=cbind(t(beta_init),t(gamma_init))
F0=diag(c(0.5,0.8),(2*m),(2*m))
Q0=diag(0.05,(2*m),(2*m))
F0_s=F0
Q0_s=Q0
theta=array(0,dim = c(T,(2*m)))
epsi_mu=rep(0,(2*m))

##################state space parameter###########################################
theta[1,]=F0%*%t(theta_init)+mvrnorm(1,epsi_mu,Q0)
alpha=rep(0,T)
alpha[1]=exp(theta[1,1]*X[1])/(1+exp(theta[1,1]*X[1]))
phi=rep(0,T)
phi[1]=1/(1+exp(theta[1,2]*Z[1]))
for (t in 1:(T-1)) {
  theta[(t+1),]=F0%*%theta[t,]+mvrnorm(1,epsi_mu,Q0)
  alpha[t+1]=exp(theta[(t+1),1]*X[t+1])/(1+exp(theta[(t+1),1]*X[t+1]))
  phi[t+1]=1/(1+exp(theta[(t+1),2]*Z[t+1]))
}

#generate INAR Phase-I sample
data_Y=c()
Y <-3#####given initial observed value
for(t in 1:T) {
  
  Y <- rbinom(1,Y,alpha[t])+rgeom(1,phi[t])
  data_Y <- c(data_Y,Y)
}
data_Y_orin=data_Y
###revised moving block bootstrap (MBB) approach
data_Y_number=tsbootstrap(1:200,nb=199,b=100,type = "block")
data_Y_number=cbind(1:200,data_Y_number)
data_Y_boot <- apply(data_Y_number, 2, function(col) data_Y[col])


beta_hat=rep(0,loop)
gamma_hat=rep(0,loop)
for (kk in 1:loop) {
  ##############estimate the model coefficients
  data_Y=as.numeric(data_Y_boot[,kk])
  Z=Z_orin[data_Y_number[1:100,kk]]
  X=X_orin[data_Y_number[1:100,kk]]
  
  T=100
  
  L_6 <- 0
  p_6 <- rep(0,(T-1))
  z_6 <- rep(NA,2)
  
  mybeta=0.5
  mygama=0.5
  
  initialvalues <- c(mybeta, mygama)
  
  GINARlik=function(z_6){
    
    
    for(k in 1:(T-1)){
      minX <- ifelse(data_Y[k]<data_Y[k+1],data_Y[k],data_Y[k+1])
      for(i in 0:minX){
        p_6[k] <- p_6[k]+choose(data_Y[k],i)*((exp(z_6[1]*X[k+1])/(1+exp(z_6[1]*X[k+1])))^i)*((1-(exp(z_6[1]*X[k+1])/(1+exp(z_6[1]*X[k+1]))))^(data_Y[k]-i))*((1/(1+exp(z_6[2]*Z[k+1])))*((1-(1/(1+exp(z_6[2]*Z[k+1]))))^(data_Y[k+1]-i)))
      }
    }
    L_6 <- -sum(log(p_6))
    return(L_6)
  }
  
  cmleG<-suppressWarnings(optim(initialvalues, GINARlik, method="BFGS")$par)
  beta_hat[kk] <- cmleG[1]
  gamma_hat[kk] <- cmleG[2]
  
}  

beta_hat_mean=mean(beta_hat)
gamma_hat_mean=mean(gamma_hat)


############################Phase-II simulation

T=200
N=700
T1=N-T

X=X_orin
Z=Z_orin

theta=rbind(theta,array(0,dim = c((T1+1),S)))
alpha=c(alpha,rep(0,T1))
phi=c(phi,rep(0,T1))

############################generate test sample 

e_control_limit=4.87
loop=2000

rl=rep(0,loop)
for (ll in 1:loop) {
  
  X[(T+1):N]=rnorm(T1,0.5,0.25)##covariate 
  Z[(T+1):N]=rnorm(T1,0.5,0.25)
  
  for (t in T:N) {
    
    alpha[t]=exp(theta[t,1]*X[t])/(1+exp(theta[t,1]*X[t]))
    phi[t]=1/(1+exp(theta[t,2]*Z[t]))
    theta[(t+1),]=F0_s%*%theta[t,]+mvrnorm(1,epsi_mu,Q0_s)
  }
  data_Y_ex=c()
  Y=data_Y_orin[T]
  for(t in (T+1):N) {
    Y <- rbinom(1,Y,alpha[t])+rgeom(1,phi[t])
    data_Y_ex <- c(data_Y_ex,Y)
  }
  data_Y[(T+1):N]=data_Y_ex
  data_Y[1:T]=data_Y_orin[1:T]
  ########################################control chart
  alpha_hat=rep(0,T1)
  for (t in 1:T1) {
    
    alpha_hat[t]=exp(beta_hat_mean*X[(t+(T-1)+1)])/(1+exp(beta_hat_mean*X[(t+(T-1)+1)]))
    
  }
  
  phi_hat=rep(0,T1)
  for (t in 1:T1) {
    
    phi_hat[t]=1/(1+exp(gamma_hat_mean*Z[(t+(T-1)+1)]))
    
  }
  
  residual=rep(0,T1)
  for (t in T:(N-1)) {
    
    residual[t-T+1]=(data_Y[(t+1)]-(alpha_hat[t-T+1]*data_Y[t]+(1-phi_hat[t-T+1])/phi_hat[t-T+1]))/
      sqrt(alpha_hat[t-(T-1)]*(1-alpha_hat[t-(T-1)])*data_Y[t]+(1-phi_hat[t-(T-1)])/(phi_hat[t-(T-1)]^2))
    
  }
  
  ##############################control chart
  
  if(min(which(residual>e_control_limit)) < Inf){
    rl[ll]=min(which(residual>e_control_limit))
  }
  if(min(which(residual>e_control_limit))==Inf){
    rl[ll]=T1
  }
  print(c(ll,rl[ll]))
}
median(rl)
rl_m=median(rl)

rl_m

write.csv(c(rl_m,e_control_limit),file = "G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\C-INAR(1)-G\\Scenario_A\\UCL.csv")


