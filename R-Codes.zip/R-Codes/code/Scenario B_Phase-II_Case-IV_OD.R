library("vars")
library("MASS")
library("stats4")
library("splines")
library("VGAM")
library("tcltk")
library("gamlss")
library("HMMpa")
library("tseries")
library("forecast")

###########Scenario B
set.seed(666)
T <- 200
S <- 2
loop=200


X=rnorm(T,0.5,0.25)##covariate 
Z=rnorm(T,0.5,0.25)

##########model parameter initial setting ################### 
m=1
beta_init=0.1
gamma_init=0.2
alpha=rep(0,T)
phi=rep(0,T)

for (t in 1:T) {
  
  alpha[t]=exp(beta_init*X[t])/(1+exp(beta_init*X[t]))
  phi[t]=1/(1+exp(gamma_init*Z[t]))
}

#generate INAR Phase-I sample
data_Y=c()
Y <-3#####given initial observed value
for(t in 1:T) {
  
  Y <- rbinom(1,Y,alpha[t])+rgeom(1,phi[t])
  data_Y <- c(data_Y,Y)
}


##################Phase-II
T=200
N=700
T1=N-T


alpha=c(alpha,rep(0,T1))
phi=c(phi,rep(0,T1))

############################Generate test sample  

e_control_limit=10
loop=2000

ss=1

rl_shift=rep(0,8)
for (delta in c(0, 0.1, 0.2, 0.4, 0.6, 0.8, 1, 1.2)) {
  rl=rep(0,loop)
  for (ll in 1:loop) {
    
    
    X[(T+1):N]=rnorm(T1,0.5,0.25)##covariate 
    Z[(T+1):N]=rnorm(T1,0.5,0.25)
    
    for (t in (T+1):N) {
      
      alpha[t]=exp(beta_init*X[t]+delta)/(1+exp(beta_init*X[t]+delta))
      phi[t]=1/(1+exp(gamma_init*Z[t]+0.3))
    }
    data_Y_ex=c()
    Y=data_Y[T]
    for(t in (T+1):N) {
      Y <- rbinom(1,Y,alpha[t])+rgeom(1,phi[t])
      data_Y_ex <- c(data_Y_ex,Y)
    }
    data_Y[(T+1):N]=data_Y_ex
    
    
    ###################################control chart  
    OD=data_Y[(T+1):N]
    
    ##############################control chart
    
    if(min(which(OD>e_control_limit)) < Inf){
      rl[ll]=min(which(OD>e_control_limit))
    }
    if(min(which(OD>e_control_limit))==Inf){
      rl[ll]=T1
    }
    print(c(ll,rl[ll]))
  }
  median(rl)
  rl_shift[ss]=median(rl)
  ss=ss+1
}
rl_shift

deltaw=rep(0.3,8)
deltaw1=c(0, 0.1, 0.2, 0.4, 0.6, 0.8, 1, 1.2)

rl_result=data.frame(T,e_control_limit,beta_init,gamma_init,deltaw1,deltaw,rl_shift)
colnames(rl_result)=c("reference_sample_size","UCL","beta0","gamma0","alpha_shift","phi_shift","MRL")

write.csv(rl_result,file = "E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\OD\\Scenario_B\\Phase-II_Case-IV.csv")







