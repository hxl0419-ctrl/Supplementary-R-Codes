library("vars")
library("MASS")
library("stats4")
library("splines")
library("VGAM")
library("tcltk")
library("gamlss")
library("HMMpa")
library("tseries")
library("forecast")
library("dfphase1")
###########
data_count <- read.csv("E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\data\\freq_brake_noise_month_201505_202312.csv", header = TRUE)
data_count_bsx=read.csv("E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\data\\freq_transmission_noise_month_201505_202312.csv",header = T)

data_Y=data_count_bsx[1:60,2]

X=Z=scale(data_count$sales)
Z=c(0,Z)
X=c(0,0,X)
set.seed(666)

T=60
S <- 2
loop=100
FF00=array(0,dim=c(S,S,loop))
QQ00=array(0,dim=c(S,S,loop))
beta_test_init=array(0,dim=c(1,S,loop))

m=1
epsi_mu=rep(0,(2*m))
data_Y_orin=data_Y

###revised moving block bootstrap (MBB) approach
data_Y_number=tsbootstrap(1:60,nb=99,b=33,type = "block")
data_Y_number=cbind(1:60,data_Y_number)
data_Y_boot <- apply(data_Y_number, 2, function(col) data_Y[col])

for (kk in 1:loop) {
  ##############initialize the model coefficients
  X=Z=scale(data_count$sales)
  Z=c(0,Z)
  X=c(0,0,X)
  
  data_Y=as.numeric(data_Y_boot[,kk])
  Z=c(Z[data_Y_number[1:33,kk]],Z[data_Y_number[33,kk]+1],Z[data_Y_number[33,kk]+2])
  X=c(X[data_Y_number[1:33,kk]],X[data_Y_number[33,kk]+1],X[data_Y_number[33,kk]+2])
  T=12
  
  L_6 <- 0
  p_6 <- rep(0,(T-1))
  z_6 <- rep(NA,2)
  
  mybeta=0.5
  mygama=0.5
  
  initialvalues <- c(mybeta, mygama)
  
  GINARlik=function(z_6){
    
    
    for(k in 1:(T-1)){
      minX <- ifelse(data_Y[k]<data_Y[k+1],data_Y[k],data_Y[k+1])
      for(i in 0:minX){
        p_6[k] <- p_6[k]+choose(data_Y[k],i)*((exp(z_6[1]*X[k+2])/(1+exp(z_6[1]*X[k+2])))^i)*((1-(exp(z_6[1]*X[k+2])/(1+exp(z_6[1]*X[k+2]))))^(data_Y[k]-i))*((1/(1+exp(z_6[2]*Z[k+2])))*((1-(1/(1+exp(z_6[2]*Z[k+2]))))^(data_Y[k+1]-i)))
      }
    }
    L_6 <- -sum(log(p_6))
    return(L_6)
  }
  
  cmleG<-suppressWarnings(optim(initialvalues, GINARlik, method="BFGS")$par)
  beta_init_hat <- cmleG[1]
  gama_init_hat <- cmleG[2]
  
  ##############initialize the value of F and Q - “sliding window” approach 
  width=12
  T=33
  
  
  beta_window_init <- rep(0,T-width+1)
  
  gama_window_init <- rep(0,T-width+1)
  
  
  
  for (j in 1:(T-width+1)){  
    L_6 <- 0
    p_6 <- rep(0,(width-1))
    z_6 <- rep(NA,2)
    Y_sliding = data_Y[j:(j+width-1)]
    X_sliding=X[(j+2):(j+width+1)]
    
    Z_sliding=Z[(j+2):(j+width+1)]
    
    Y_sliding <- as.numeric(Y_sliding)
    n <- length(Y_sliding)
    
    mybeta <- 0.5
    mygama <- 0.5
    
    
    initialvalues_w <- c(mybeta, mygama)
    
    
    GINARlik_window=function(z_6){
      
      for(k in 1:(n-1)){
        minX <- ifelse(Y_sliding[k]<Y_sliding[k+1],Y_sliding[k],Y_sliding[k+1])
        for(i in 0:minX){
          p_6[k] <- p_6[k]+choose(Y_sliding[k],i)*((exp(z_6[1]*X_sliding[k])/(1+exp(z_6[1]*X_sliding[k])))^i)*((1-(exp(z_6[1]*X_sliding[k])/(1+exp(z_6[1]*X_sliding[k]))))^(Y_sliding[k]-i))*((1/(1+exp(z_6[2]*Z_sliding[k])))*((1-(1/(1+exp(z_6[2]*Z_sliding[k]))))^(Y_sliding[k+1]-i)))
        }
      }
      L_6 <- -sum(log(p_6))
      return(L_6)
    }
    
    
    cmleG_window<-suppressWarnings(optim(initialvalues_w, GINARlik_window, method = "BFGS")$par)
    
    beta_window_init[j] <- cmleG_window[1]
    gama_window_init[j] <- cmleG_window[2]
    
    
  }
  
  ######################################state space model
  mm=60
  T=60
  
  beta0_Init <- data.frame(beta_window_init,gama_window_init)
  colnames(beta0_Init)=c("beta","gamma")
  
  beta0_hat <- array(0,dim = c(T,S)) 
  beta0_hat_c <- array(0,dim = c(T,S)) 
  beta0_hat_S <- array(0,dim = c(T,S))
  colnames(beta0_hat)=c("beta","gamma")   
  beta0_hat[1,] <- c(beta_init_hat,gama_init_hat)
  H <- matrix(0,T,S)
  K <- array(0,dim = c(T,S))
  R <- array(0,dim = c(T))
  J <- array(0,dim=c(S,S,T)) #prcoss matrix
  I <- array(0,dim=c(S,S,2)) #iteration stop matrix
  P0 <- array(0,dim=c(S,S,T))###prediction covariance matrix
  P1 <- array(0,dim=c(S,S,T))###correction covariance matrix
  P2 <- array(0,dim=c(S,S,T))###smoothing covariance matrix
  P <- array(0,dim=c(S,S,T))###E step
  P12 <- array(0,dim=c(S,S,T))###E step
  EP12 <- array(0,dim=c(S,S,T))###E step
  f <- array(0,dim=c(mm,S,T)) #Monte Carlo filter 
  
  alpha_hat <- rep(0,(T-1))
  phi_hat <- rep(0,(T-1))
  Cov0_matrix <- array(0,dim=c(S,S))
  
  
  if(kk==1){
    Var0 <- VAR(data.frame(beta0_Init[,1:2]), p = 1, type = "none")
    
    F0 <- matrix(c(Var0$varresult$beta$coefficients,Var0$varresult$gamma$coefficients),S,S,byrow = T)
    Q0 <-summary(Var0)$covres
    F0=F0-matrix(c(0,F0[2,1],F0[1,2],0),2,2)
    Q0=Q0-matrix(c(0,Q0[2,1],Q0[1,2],0),2,2)
  }
  
  Cov0_matrix <- cov(beta0_Init)
  P0[,,1] <- F0%*%Cov0_matrix%*%t(F0)+Q0
  
  
  
  
  T=33
  
  loop_em=20###EM
  for (l in 1:loop_em) {
    A=F0
    AA=Q0
    ######Kalman Filter
    for (t in 1:(T-1)) {
      ###############correction step
      H[t,] <- rbind(data_Y[t]*(exp(beta0_hat[t,1]*X[(t+2)]))*X[(t+2)]/(1+exp(beta0_hat[t,1]*X[(t+2)]))^2,
                     Z[(t+2)]*exp(beta0_hat[t,2]*Z[(t+2)]))
      
      R[t] <- (1-(1/(1+exp(beta0_hat[t,2]*Z[(t+2)]))))/
        (((1/(1+exp(beta0_hat[t,2]*Z[(t+2)])))^2)*(1-(exp(beta0_hat[t,1]*X[(t+2)])/(1+exp(beta0_hat[t,1]*X[(t+2)])))))
      K[t,] <- P0[,,t]%*%H[t,]%*%solve(t(H[t,])%*%P0[,,t]%*%H[t,]+R[t]) 
      beta0_hat_c[t,] <- beta0_hat[t,]+K[t,]*(data_Y[t+1]-((exp(beta0_hat[t,1]*X[(t+2)])/(1+exp(beta0_hat[t,1]*X[(t+2)])))*
                                                             data_Y[t]+exp(beta0_hat[t,2]*Z[(t+2)])))
      P1[,,t] <- (diag(S)-K[t,]%*%t(H[t,]))%*%P0[,,t]
      
      #############prediction step
      beta0_hat[(t+1),]=F0%*%beta0_hat_c[t,]
      P0[,,(t+1)] <- F0%*%P1[,,t]%*%t(F0)+Q0
    }
    ######Kalman smoothing(E step)
    beta0_hat_S[(T-1),]=beta0_hat_c[(T-1),]###sample T
    P2[,,(T-1)]=P1[,,(T-1)]
    
    for (t in (T-2):1) {
      J[,,t]=P1[,,t]%*%t(F0)%*%solve(P0[,,(t+1)])
      beta0_hat_S[t,]=beta0_hat_c[t,]+J[,,t]%*%(beta0_hat_S[(t+1),]-F0%*%beta0_hat_c[t,])
      P2[,,t]=P1[,,t]+J[,,t]%*%(P2[,,(t+1)]-P0[,,(t+1)])%*%t(J[,,t])
    }
    ######M step
    for (t in (T-1):1) {
      P[,,t]=P2[,,t]+beta0_hat_S[t,]%*%t(beta0_hat_S[t,])###corresponding P_t for t=T-1,...1
    }
    P12[,,(T-1)]=(diag(S)-K[(T-1),]%*%t(H[(T-1),]))%*%F0%*%P1[,,(T-2)]
    for (t in (T-2):2) {
      P12[,,t]=P1[,,t]%*%t(J[,,(t-1)])+J[,,t]%*%(t(P12[,,(t+1)])-F0%*%P1[,,t])%*%t(J[,,(t-1)])###V_t,t-1
    }
    for (t in (T-1):2) {
      EP12[,,t]=P12[,,t]+beta0_hat_S[t,]%*%t(beta0_hat_S[(t-1),])###P_t,t-1
    }
    for (t in 1:(T-1)) {
      alpha_hat[t]=exp(beta0_hat_S[t,1]*X[(t+2)])/(1+exp(beta0_hat_S[t,1]*X[(t+2)]))
      
    }
    for (t in 1:(T-1)) {
      phi_hat[t]=1/(1+exp(beta0_hat_S[t,2]*Z[(t+2)]))
      
    }
    
    F0=apply(EP12, MARGIN = c(1, 2), FUN = sum)%*%solve(apply(P[,,1:(T-2)], MARGIN = c(1, 2), FUN = sum))
    F0=F0-matrix(c(0,F0[2,1],F0[1,2],0),2,2)
    Q0=1/(T-2)*(apply(P[,,2:(T-1)], MARGIN = c(1, 2), FUN = sum)-F0%*%t(apply(EP12, MARGIN = c(1, 2), FUN = sum)))
    Q0=Q0-matrix(c(0,Q0[2,1],Q0[1,2],0),2,2)
    P0[,,1]=P[,,1]-beta0_hat_S[1,]%*%t(beta0_hat_S[1,])
    # Frobenius norm
    B=F0
    BB=Q0
    norm_diff_F0_u <- sqrt(sum((A - B)^2))
    norm_diff_Q0_u <- sqrt(sum((AA - BB)^2))
    
    if(max(abs(c(norm_diff_F0_u, norm_diff_Q0_u)))<10^-6){break}
    
    
    beta0_hat[1,]=beta0_hat_S[1,]
    
    
  }
  
  
  
  
  
  FF00[,,kk]=F0
  QQ00[,,kk]=Q0
  beta_test_init[,,kk]=beta0_hat_S[1,]
  
  
}

print(l)
F0=apply(FF00[,,20:100], MARGIN = c(1, 2), FUN = mean)
Q0=apply(QQ00[,,20:100], MARGIN = c(1, 2), FUN = mean)
beta0_hat[1,]=apply(beta_test_init, MARGIN = c(1, 2), FUN = mean)

X=Z=scale(data_count$sales)
Z=c(0,Z)
X=c(0,0,X)

for (t in 1:59) {
  ###############correction step
  H[t,] <- rbind(data_Y_orin[t]*(exp(beta0_hat[t,1]*X[(t+2)]))*X[(t+2)]/(1+exp(beta0_hat[t,1]*X[(t+2)]))^2,
                 Z[(t+2)]*exp(beta0_hat[t,2]*Z[(t+2)]))
  
  R[t] <- (1-(1/(1+exp(beta0_hat[t,2]*Z[(t+2)]))))/
    (((1/(1+exp(beta0_hat[t,2]*Z[(t+2)])))^2)*(1-(exp(beta0_hat[t,1]*X[(t+2)])/(1+exp(beta0_hat[t,1]*X[(t+2)])))))
  K[t,] <- P0[,,t]%*%H[t,]%*%solve(t(H[t,])%*%P0[,,t]%*%H[t,]+R[t]) 
  beta0_hat_c[t,] <- beta0_hat[t,]+K[t,]*(data_Y_orin[t+1]-((exp(beta0_hat[t,1]*X[(t+2)])/(1+exp(beta0_hat[t,1]*X[(t+2)])))*
                                                              data_Y_orin[t]+exp(beta0_hat[t,2]*Z[(t+2)])))
  P1[,,t] <- (diag(S)-K[t,]%*%t(H[t,]))%*%P0[,,t]
  
  #############prediction step
  beta0_hat[(t+1),]=F0%*%beta0_hat_c[t,]
  P0[,,(t+1)] <- F0%*%P1[,,t]%*%t(F0)+Q0
}

T=60
######Kalman smoothing
beta0_hat_S[(T-1),]=beta0_hat_c[(T-1),]###sample T


for (t in (T-2):1) {
  J[,,t]=P1[,,t]%*%t(F0)%*%solve(P0[,,(t+1)])
  beta0_hat_S[t,]=beta0_hat_c[t,]+J[,,t]%*%(beta0_hat_S[(t+1),]-F0%*%beta0_hat_c[t,])
  
}

alpha_hat=rep(0,T)###sample (T+1):N
for (t in 1:T) {
  
  alpha_hat[t]=exp(beta0_hat_S[t,1]*X[(t+2)])/(1+exp(beta0_hat_S[t,1]*X[(t+2)]))
  
}

phi_hat=rep(0,T)
for (t in 1:T) {
  
  phi_hat[t]=1/(1+exp(beta0_hat_S[t,2]*Z[(t+2)]))
  
}
residual=rep(0,T)
for (t in 1:(T-1)) {
  
  
  
  
  residual[t+1]=(data_Y_orin[(t+1)]-(alpha_hat[t]*data_Y_orin[t]+(1-phi_hat[t])/phi_hat[t]))/
    sqrt(alpha_hat[t]*(1-alpha_hat[t])*data_Y_orin[t]+(1-phi_hat[t])/(phi_hat[t]^2))
  
}

write.table(residual,file = "E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\SDC-INAR(1)-G\\transmission\\Phase-I_residual.csv",col.names = "residual",row.names = FALSE,sep = ",")

plot(residual)
mean(residual)
var(residual)
Box.test(residual)
rsp(residual)




# #Transition probabilities of INAR(1)-G model:
# tpgeom <- function(k,l,prob,alpha){
#   tp <- 0
#   for(j in c(0:min(k,l))){
#     tp <- tp + dbinom(j,l,alpha)*dgeom(k-j,prob)
#   }
#   tp
# }
# 
# 
# data=data_Y_orin
# T0=60
# #PIT:
# maxval=max(data)
# #Matrix of all CDFs for each time point:
# allcdfs <- array(0, c(maxval+2, maxval+1, T0)) #3D array for time-varying CDFs
# 
# for(t in 1:T0) {
#   for(l in 0:maxval) {
#     cpmf <- rep(0, (maxval+1))
#     for(k in 0:maxval) {
#       cpmf[k+1] <- tpgeom(k, l, alpha_hat[t], phi_hat[t])
#     }
#     allcdfs[(2:(maxval+2)), l+1, t] <- cumsum(cpmf)
#   }
# }
# 
# nobins <- 10
# PIT <- array(0, c(2, nobins+1))
# 
# for(j in 1:nobins) {
#   u <- j/nobins
#   pitval <- 0
#   
#   for(t in 2:T0) {
#     if(allcdfs[(data[t]+1), (data[t-1]+1), t] < u) {
#       if(allcdfs[(data[t]+2), (data[t-1]+1), t] < u) {
#         pitval <- pitval + 1
#       } else {
#         pitval <- pitval + (u - allcdfs[(data[t]+1), (data[t-1]+1), t]) / 
#           (allcdfs[(data[t]+2), (data[t-1]+1), t] - allcdfs[(data[t]+1), (data[t-1]+1), t])
#       }
#     }
#   }
#   PIT[1, j+1] <- pitval/(T0-1)
#   PIT[2, j+1] <- PIT[1, j+1] - PIT[1, j]
# }
# 
# PIT.freq = as.vector(rep(((1:nobins)-0.5)/nobins, PIT[2, 2:(nobins+1)]*1000))
# PIT.hist <- hist(PIT.freq, plot=FALSE, breaks=nobins)
# PIT.hist$counts <- PIT.hist$counts/1000
# plot(PIT.hist, freq=TRUE, main="PIT histogram", ylab="PIT histogram", xlab="u", col="gray")
# 
# 
# 
