library(ggplot2)
library(scales)
library(gridExtra)
library(ggfortify)
library(grid)

jpeg(
  filename = "G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\figure\\Figure_5.jpeg",
  width = 3000, 
  height = 2000, 
  res = 300, 
  quality = 100
)

data_count <- read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\data\\freq_brake_noise_month_201505_202312.csv", header = TRUE)


df <- data.frame(
  date_x = seq(as.Date('2015/5/1'), as.Date('2023/12/31'), by = "month"),
  value = scale(data_count$sales)
)


ggplot(df, aes(x = date_x, y = value)) +
  geom_line() +
  geom_point()+
  labs(
    x = "Date(year/month)",           
    y = "Sales(standardized)",                   
    
  ) +
  theme(panel.background = element_blank(), 
        panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(), 
        axis.line = element_line(colour = "black"), 
        axis.ticks = element_line(colour = "black"), 
        axis.text.x = element_text(angle = 45, hjust = 1))+
  scale_x_date(
    breaks = date_breaks("2 month"), 
    labels = date_format("%Y/%m"),    
    limits = c(as.Date('2015/5/1',format("%Y/%m/%d")), as.Date('2023/12/31',format("%Y/%m/%d"))) # 设置x轴的开始和结束时间
  ) 

dev.off()