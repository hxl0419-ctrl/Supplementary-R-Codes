library("vars")
library("MASS")
library("stats4")
library("splines")
library("VGAM")
library("tcltk")
library("gamlss")
library("HMMpa")
library("tseries")
library("forecast")
library("dfphase1")

###########
data_count <- read.csv("E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\data\\freq_brake_noise_month_201505_202312.csv", header = TRUE)
data_Y=data_count$MF[1:60]


X=Z=scale(data_count$sales)
Z=c(0,Z)
X=c(0,0,X)
set.seed(1)

T=60
S <- 2
loop=100


m=1
epsi_mu=rep(0,(2*m))
data_Y_orin=data_Y

###revised moving block bootstrap (MBB) approach
data_Y_number=tsbootstrap(1:60,nb=99,b=33,type = "block")
data_Y_number=cbind(1:60,data_Y_number)
data_Y_boot <- apply(data_Y_number, 2, function(col) data_Y[col])

beta_hat=rep(0,loop)
gamma_hat=rep(0,loop)
for (kk in 1:loop) {
  ##############estimate the model coefficients
  X=Z=scale(data_count$sales)
  Z=c(0,Z)
  X=c(0,0,X)
  
  data_Y=as.numeric(data_Y_boot[,kk])
  Z=c(Z[data_Y_number[1:33,kk]],Z[data_Y_number[33,kk]+1],Z[data_Y_number[33,kk]+2])
  X=c(X[data_Y_number[1:33,kk]],X[data_Y_number[33,kk]+1],X[data_Y_number[33,kk]+2])
  T=33
  
  L_6 <- 0
  p_6 <- rep(0,(T-1))
  z_6 <- rep(NA,2)
  
  mybeta=0.5
  mygama=0.5
  
  initialvalues <- c(mybeta, mygama)
  
  GINARlik=function(z_6){
    
    
    for(k in 1:(T-1)){
      minX <- ifelse(data_Y[k]<data_Y[k+1],data_Y[k],data_Y[k+1])
      for(i in 0:minX){
        p_6[k] <- p_6[k]+choose(data_Y[k],i)*((exp(z_6[1]*X[k+2])/(1+exp(z_6[1]*X[k+2])))^i)*((1-(exp(z_6[1]*X[k+2])/(1+exp(z_6[1]*X[k+2]))))^(data_Y[k]-i))*((1/(1+exp(z_6[2]*Z[k+2])))*((1-(1/(1+exp(z_6[2]*Z[k+2]))))^(data_Y[k+1]-i)))
      }
    }
    L_6 <- -sum(log(p_6))
    return(L_6)
  }
  
  cmleG<-suppressWarnings(optim(initialvalues, GINARlik, method="BFGS")$par)
  beta_hat[kk] <- cmleG[1]
  gamma_hat[kk] <- cmleG[2]
  
}  

beta_hat_mean=mean(beta_hat)
gamma_hat_mean=mean(gamma_hat)

T=60
X=Z=scale(data_count$sales)
Z=c(0,Z)
X=c(0,0,X)

alpha_hat=rep(0,T)###sample (T+1):N
for (t in 1:T) {
  
  alpha_hat[t]=exp(beta_hat_mean*X[(t+2)])/(1+exp(beta_hat_mean*X[(t+2)]))
  
}

phi_hat=rep(0,T)
for (t in 1:T) {
  
  phi_hat[t]=1/(1+exp(gamma_hat_mean*Z[(t+2)]))
  
}
residual=rep(0,T)
for (t in 1:(T-1)) {
  
  
  
  
  residual[t+1]=(data_Y_orin[(t+1)]-(alpha_hat[t]*data_Y_orin[t]+(1-phi_hat[t])/phi_hat[t]))/
    sqrt(alpha_hat[t]*(1-alpha_hat[t])*data_Y_orin[t]+(1-phi_hat[t])/(phi_hat[t]^2))
  
}

write.table(residual,file = "E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\C-INAR(1)-G\\Brake\\Phase-I_residual.csv",col.names = "residual",row.names = FALSE,sep = ",")
plot(residual)
mean(residual)
var(residual)
Box.test(residual)
rsp(residual)


#Transition probabilities of INAR(1)-G model:
# tpgeom <- function(k,l,prob,alpha){
#   tp <- 0
#   for(j in c(0:min(k,l))){
#     tp <- tp + dbinom(j,l,alpha)*dgeom(k-j,prob)
#   }
#   tp
# }
# 
# 
# data=data_Y_orin
# T0=60
# #PIT:
# maxval=max(data)
# #Matrix of all CDFs for each time point:
# allcdfs <- array(0, c(maxval+2, maxval+1, T0)) #3D array for time-varying CDFs
# 
# for(t in 1:T0) {
#   for(l in 0:maxval) {
#     cpmf <- rep(0, (maxval+1))
#     for(k in 0:maxval) {
#       cpmf[k+1] <- tpgeom(k, l, alpha_hat[t], phi_hat[t])
#     }
#     allcdfs[(2:(maxval+2)), l+1, t] <- cumsum(cpmf)
#   }
# }
# 
# nobins <- 10
# PIT <- array(0, c(2, nobins+1))
# 
# for(j in 1:nobins) {
#   u <- j/nobins
#   pitval <- 0
#   
#   for(t in 2:T0) {
#     if(allcdfs[(data[t]+1), (data[t-1]+1), t] < u) {
#       if(allcdfs[(data[t]+2), (data[t-1]+1), t] < u) {
#         pitval <- pitval + 1
#       } else {
#         pitval <- pitval + (u - allcdfs[(data[t]+1), (data[t-1]+1), t]) / 
#           (allcdfs[(data[t]+2), (data[t-1]+1), t] - allcdfs[(data[t]+1), (data[t-1]+1), t])
#       }
#     }
#   }
#   PIT[1, j+1] <- pitval/(T0-1)
#   PIT[2, j+1] <- PIT[1, j+1] - PIT[1, j]
# }
# 
# PIT.freq = as.vector(rep(((1:nobins)-0.5)/nobins, PIT[2, 2:(nobins+1)]*1000))
# PIT.hist <- hist(PIT.freq, plot=FALSE, breaks=nobins)
# PIT.hist$counts <- PIT.hist$counts/1000
# plot(PIT.hist, freq=TRUE, main="PIT histogram", ylab="PIT histogram", xlab="u", col="gray")
# 
# 
# 
