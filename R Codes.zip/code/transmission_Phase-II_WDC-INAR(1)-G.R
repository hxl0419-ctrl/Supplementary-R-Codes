library("vars")
library("MASS")
library("stats4")
library("splines")
library("VGAM")
library("tcltk")
library("gamlss")
library("HMMpa")
library("tseries")

###########
data_count <- read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\data\\freq_brake_noise_month_201505_202312.csv", header = TRUE)
data_count_bsx=read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\data\\freq_transmission_noise_month_201505_202312.csv",header = T)

data_Y=data_count_bsx[1:60,2]

X=Z=scale(data_count$sales)
Z=c(0,Z)
X=c(0,0,X)
set.seed(666)

T=60
S <- 2
loop=100
FF00=array(0,dim=c(S,S,loop))
QQ00=array(0,dim=c(S,S,loop))


m=1
epsi_mu=rep(0,(2*m))
data_Y_orin=data_Y

###revised moving block bootstrap (MBB) approach
data_Y_number=tsbootstrap(1:60,nb=99,b=33,type = "block")
data_Y_number=cbind(1:60,data_Y_number)
data_Y_boot <- apply(data_Y_number, 2, function(col) data_Y[col])

beta_init_hat=rep(0,loop)
gamma_init_hat=rep(0,loop)
for (kk in 1:loop) {
  ##############estimate the model coefficients
  X=Z=scale(data_count$sales)
  Z=c(0,Z)
  X=c(0,0,X)
  
  data_Y=as.numeric(data_Y_boot[,kk])
  Z=c(Z[data_Y_number[1:33,kk]],Z[data_Y_number[33,kk]+1],Z[data_Y_number[33,kk]+2])
  X=c(X[data_Y_number[1:33,kk]],X[data_Y_number[33,kk]+1],X[data_Y_number[33,kk]+2])
  T=15
  
  L_6 <- 0
  p_6 <- rep(0,(T-1))
  z_6 <- rep(NA,2)
  
  mybeta=0.5
  mygama=0.5
  
  initialvalues <- c(mybeta, mygama)
  
  GINARlik=function(z_6){
    
    
    for(k in 1:(T-1)){
      minX <- ifelse(data_Y[k]<data_Y[k+1],data_Y[k],data_Y[k+1])
      for(i in 0:minX){
        p_6[k] <- p_6[k]+choose(data_Y[k],i)*((exp(z_6[1]*X[k+2])/(1+exp(z_6[1]*X[k+2])))^i)*((1-(exp(z_6[1]*X[k+2])/(1+exp(z_6[1]*X[k+2]))))^(data_Y[k]-i))*((1/(1+exp(z_6[2]*Z[k+2])))*((1-(1/(1+exp(z_6[2]*Z[k+2]))))^(data_Y[k+1]-i)))
      }
    }
    L_6 <- -sum(log(p_6))
    return(L_6)
  }
  
  cmleG<-suppressWarnings(optim(initialvalues, GINARlik, method="BFGS")$par)
  beta_init_hat[kk] <- cmleG[1]
  gamma_init_hat[kk] <- cmleG[2]
  
  ##############windows parameter estimate 
  width=15
  T=33
  
  
  beta_window_init <- rep(0,T-width+1)
  
  gamma_window_init <- rep(0,T-width+1)
  
  
  
  for (j in 1:(T-width+1)){  
    L_6 <- 0
    p_6 <- rep(0,(width-1))
    z_6 <- rep(NA,2)
    Y_sliding = data_Y[j:(j+width-1)]
    X_sliding=X[(j+2):(j+width+1)]
    
    Z_sliding=Z[(j+2):(j+width+1)]
    
    Y_sliding <- as.numeric(Y_sliding)
    n <- length(Y_sliding)
    
    mybeta <- 0.5
    mygama <- 0.5
    
    
    initialvalues_w <- c(mybeta, mygama)
    
    
    GINARlik_window=function(z_6){
      
      for(k in 1:(n-1)){
        minX <- ifelse(Y_sliding[k]<Y_sliding[k+1],Y_sliding[k],Y_sliding[k+1])
        for(i in 0:minX){
          p_6[k] <- p_6[k]+choose(Y_sliding[k],i)*((exp(z_6[1]*X_sliding[k])/(1+exp(z_6[1]*X_sliding[k])))^i)*((1-(exp(z_6[1]*X_sliding[k])/(1+exp(z_6[1]*X_sliding[k]))))^(Y_sliding[k]-i))*((1/(1+exp(z_6[2]*Z_sliding[k])))*((1-(1/(1+exp(z_6[2]*Z_sliding[k]))))^(Y_sliding[k+1]-i)))
          if(p_6[k]<1e-10){p_6[k]=1e-10}
        }
      }
      L_6 <- -sum(log(p_6))
      return(L_6)
    }
    
    
    cmleG_window<-suppressWarnings(optim(initialvalues_w, GINARlik_window, method="BFGS")$par)
    
    beta_window_init[j] <- cmleG_window[1]
    gamma_window_init[j] <- cmleG_window[2]
    
    
  }
  
  beta0_Init <- data.frame(beta_window_init,gamma_window_init)
  colnames(beta0_Init)=c("beta","gamma")
  Cov0_matrix <- array(0,dim=c(S,S))
  Var0 <- VAR(data.frame(beta0_Init[,1:2]), p = 1, type = "none")
  
  F0 <- matrix(c(Var0$varresult$beta$coefficients,Var0$varresult$gamma$coefficients),S,S,byrow = T)
  Q0 <-summary(Var0)$covres
  F0=F0-matrix(c(0,F0[2,1],F0[1,2],0),2,2)
  Q0=Q0-matrix(c(0,Q0[2,1],Q0[1,2],0),2,2)
  FF00[,,kk]=F0
  QQ00[,,kk]=Q0
  
}

F0=apply(FF00, MARGIN = c(1, 2), FUN = mean)
Q0=apply(QQ00, MARGIN = c(1, 2), FUN = mean)




T=60
H <- matrix(0,T,S)
K <- array(0,dim = c(T,S))
R <- array(0,dim = c(T))
P0 <- array(0,dim=c(S,S,T))###prediction covariance matrix
P1 <- array(0,dim=c(S,S,T))###correction covariance matrix
J <- array(0,dim=c(S,S,T)) #prcoss matrix
beta0_hat <- array(0,dim = c(T,S))
beta0_hat_S <- array(0,dim = c(T,S))
beta0_hat_c <- array(0,dim = c(T,S))
beta0_hat[1,]=c(mean(beta_init_hat),mean(gamma_init_hat))
P0[,,1] <- cov(cbind(beta_init_hat,gamma_init_hat))

X=Z=scale(data_count$sales)
Z=c(0,Z)
X=c(0,0,X)

for (t in 1:(T-1)) {
  
  H[t,] <- rbind(data_Y_orin[t]*(exp(beta0_hat[t,1]*X[(t+2)]))*X[(t+2)]/(1+exp(beta0_hat[t,1]*X[(t+2)]))^2,
                 Z[(t+2)]*exp(beta0_hat[t,2]*Z[(t+2)]))
  
  R[t] <- (1-(1/(1+exp(beta0_hat[t,2]*Z[(t+2)]))))/
    (((1/(1+exp(beta0_hat[t,2]*Z[(t+2)])))^2)*(1-(exp(beta0_hat[t,1]*X[(t+2)])/(1+exp(beta0_hat[t,1]*X[(t+2)])))))
  K[t,] <- P0[,,t]%*%H[t,]%*%solve(t(H[t,])%*%P0[,,t]%*%H[t,]+R[t]) 
  beta0_hat_c[t,] <- beta0_hat[t,]+K[t,]*(data_Y_orin[t+1]-((exp(beta0_hat[t,1]*X[(t+2)])/(1+exp(beta0_hat[t,1]*X[(t+2)])))*
                                                              data_Y_orin[t]+exp(beta0_hat[t,2]*Z[(t+2)])))
  P1[,,t] <- (diag(S)-K[t,]%*%t(H[t,]))%*%P0[,,t]
  
  #############prediction step
  beta0_hat[(t+1),]=F0%*%beta0_hat_c[t,]
  P0[,,(t+1)] <- F0%*%P1[,,t]%*%t(F0)+Q0
  
}


########################phase-II
T=60
N=104
T1=N-T
beta0_hat=rbind(beta0_hat,array(0,dim = c(T1,S)))
beta0_hat_c=rbind(beta0_hat_c,array(0,dim = c(T1,S)))
P0_expanded <- array(0, dim = c(S, S, N))
P0_expanded[, , 1:T] <- P0
P1_expanded <- array(0, dim = c(S, S, N))
P1_expanded[, , 1:T] <- P1
H=rbind(H,array(0,dim = c(T1,S)))
K=rbind(K,array(0,dim = c(T1,S)))
R=c(R,rep(0,T1))

############################test sample 

e_control_limit=12.69


data_Y=data_count_bsx[,2]
X=Z=scale(data_count$sales)
Z=c(0,Z)
X=c(0,0,X)

########################################model_based



for(t in T:(N-1)){
  
  
  
  H[t,] <- rbind(data_Y[t]*(exp(beta0_hat[t,1]*X[(t+2)]))*X[(t+2)]/(1+exp(beta0_hat[t,1]*X[(t+2)]))^2,
                 Z[(t+2)]*exp(beta0_hat[t,2]*Z[(t+2)]))
  
  R[t] <- (1-(1/(1+exp(beta0_hat[t,2]*Z[(t+2)]))))/
    (((1/(1+exp(beta0_hat[t,2]*Z[(t+2)])))^2)*(1-(exp(beta0_hat[t,1]*X[(t+2)])/(1+exp(beta0_hat[t,1]*X[(t+2)])))))
  K[t,] <- P0_expanded[,,t]%*%H[t,]%*%solve(t(H[t,])%*%P0_expanded[,,t]%*%H[t,]+R[t]) 
  beta0_hat_c[t,] <- beta0_hat[t,]+K[t,]*(data_Y[t+1]-((exp(beta0_hat[t,1]*X[(t+2)])/(1+exp(beta0_hat[t,1]*X[(t+2)])))*
                                                         data_Y[t]+exp(beta0_hat[t,2]*Z[(t+2)])))
  P1_expanded[,,t] <- (diag(S)-K[t,]%*%t(H[t,]))%*%P0_expanded[,,t]
  
  #############prediction step
  beta0_hat[(t+1),]=F0%*%beta0_hat_c[t,]
  P0_expanded[,,(t+1)] <- F0%*%P1_expanded[,,t]%*%t(F0)+Q0
  
  
}
beta0_hat_c[N,]=beta0_hat[N,]

statistic=rep(0,T1)
for (t in T:(N-1)) {
  
  statistic[t-T+1]=(exp(beta0_hat_c[t,1]*X[(t+2)])/(1+exp(beta0_hat_c[t,1]*X[(t+2)])))*
    data_Y[t]+exp(beta0_hat_c[t,2]*Z[(t+2)])
}
which(statistic>e_control_limit)+T
data_Y[which(statistic>e_control_limit)+T]
statistic[which(statistic>e_control_limit)]
rl_result=data.frame(e_control_limit,seq(T+1,N),data_Y[(T+1):N],statistic)
colnames(rl_result)=c("UCL","Sample Number","Data","Statistics")


write.csv(rl_result,file = "G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\WDC-INAR(1)-G\\Transmission\\Phase-II.csv")
