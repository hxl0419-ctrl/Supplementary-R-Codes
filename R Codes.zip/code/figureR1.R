Scenario_A_s=read.csv("E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\SDC-INAR(1)-G\\Scenario_A\\robust_NB.csv")
Scenario_A_c=read.csv("E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\C-INAR(1)-G\\Scenario_A\\robust_NB.csv")
Scenario_A_I=read.csv("E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\INAR(1)-G\\Scenario_A\\robust_NB.csv")
Scenario_A_w=read.csv("E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\WDC-INAR(1)-G\\Scenario_A\\robust_NB.csv")
Scenario_B_s=read.csv("E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\SDC-INAR(1)-G\\Scenario_A\\robust_NB.csv")
Scenario_B_c=read.csv("E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\C-INAR(1)-G\\Scenario_A\\robust_NB.csv")
Scenario_B_I=read.csv("E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\INAR(1)-G\\Scenario_A\\robust_NB.csv")
Scenario_B_w=read.csv("E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\WDC-INAR(1)-G\\Scenario_A\\robust_NB.csv")


jpeg(filename = "E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\figure\\Figure_R1.jpeg", width = 2000, height = 1700, quality = 5000, res = 200)
layout(matrix(1:2, nrow=2))


legend_labels <- c("SDC-INAR(1)-G", "C-INAR(1)-G", "INAR(1)-G", "WDC-INAR(1)-G")
legend_lty <- c(1, 2, 3, 4) 
legend_pch <- c(2, 18, 4, 1) 

############################################# Scenario_A
rl <- seq(1,2,0.1)
max_mrl <- max(Scenario_A_s$MRL0, Scenario_A_c$MRL0, Scenario_A_I$MRL0, Scenario_A_w$MRL0, na.rm = TRUE)
plot(rl, Scenario_A_s$MRL0, type="o", lty=legend_lty[1], pch=legend_pch[1], 
     xlab=expression(r), ylab="MRL", main="Scenario A", 
     ylim=c(0, max_mrl * 1.25))
lines(rl, Scenario_A_c$MRL, type="o", lty=legend_lty[2], pch=legend_pch[2])
lines(rl, Scenario_A_I$MRL, type="o", lty=legend_lty[3], pch=legend_pch[3])
lines(rl, Scenario_A_w$MRL, type="o", lty=legend_lty[4], pch=legend_pch[4])
legend("topleft", legend=legend_labels, lty=legend_lty, pch=legend_pch, bty="n")

############################################# Scenario_B
rl <- seq(1,2,0.1)
max_mrl <- max(Scenario_B_s$MRL0, Scenario_B_c$MRL0, Scenario_B_I$MRL0, Scenario_B_w$MRL0, na.rm = TRUE)
plot(rl, Scenario_B_s$MRL0, type="o", lty=legend_lty[1], pch=legend_pch[1], 
     xlab=expression(r), ylab="MRL", main="Scenario B", 
     ylim=c(0, max_mrl * 1.25))
lines(rl, Scenario_B_c$MRL, type="o", lty=legend_lty[2], pch=legend_pch[2])
lines(rl, Scenario_B_I$MRL, type="o", lty=legend_lty[3], pch=legend_pch[3])
lines(rl, Scenario_B_w$MRL, type="o", lty=legend_lty[4], pch=legend_pch[4])
legend("topleft", legend=legend_labels, lty=legend_lty, pch=legend_pch, bty="n")


dev.off()
