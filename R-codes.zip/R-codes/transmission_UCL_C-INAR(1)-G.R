library("vars")
library("MASS")
library("stats4")
library("splines")
library("VGAM")
library("tcltk")
library("gamlss")
library("HMMpa")
library("Rsolnp")
library("tseries")

###########
data_count <- read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\data\\freq_brake_noise_month_201505_202312.csv", header = TRUE)
data_count_bsx=read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\data\\freq_transmission_noise_month_201505_202312.csv",header = T)

data_Y=data_count_bsx[1:60,2]


X=Z=scale(data_count$sales)
Z=c(0,Z)
X=c(0,0,X)
set.seed(1)

T=60
S <- 2
loop=100


m=1
epsi_mu=rep(0,(2*m))
data_Y_orin=data_Y

###revised moving block bootstrap (MBB) approach
data_Y_number=tsbootstrap(1:60,nb=99,b=33,type = "block")
data_Y_number=cbind(1:60,data_Y_number)
data_Y_boot <- apply(data_Y_number, 2, function(col) data_Y[col])

beta_hat=rep(0,loop)
gamma_hat=rep(0,loop)
for (kk in 1:loop) {
  ##############estimate the model coefficients
  X=Z=scale(data_count$sales)
  Z=c(0,Z)
  X=c(0,0,X)
  
  data_Y=as.numeric(data_Y_boot[,kk])
  Z=c(Z[data_Y_number[1:33,kk]],Z[data_Y_number[33,kk]+1],Z[data_Y_number[33,kk]+2])
  X=c(X[data_Y_number[1:33,kk]],X[data_Y_number[33,kk]+1],X[data_Y_number[33,kk]+2])
  T=33
  
  L_6 <- 0
  p_6 <- rep(0,(T-1))
  z_6 <- rep(NA,2)
  
  mybeta=0.5
  mygama=0.5
  
  initialvalues <- c(mybeta, mygama)
  
  GINARlik=function(z_6){
    
    
    for(k in 1:(T-1)){
      minX <- ifelse(data_Y[k]<data_Y[k+1],data_Y[k],data_Y[k+1])
      for(i in 0:minX){
        p_6[k] <- p_6[k]+choose(data_Y[k],i)*((exp(z_6[1]*X[k+2])/(1+exp(z_6[1]*X[k+2])))^i)*((1-(exp(z_6[1]*X[k+2])/(1+exp(z_6[1]*X[k+2]))))^(data_Y[k]-i))*((1/(1+exp(z_6[2]*Z[k+2])))*((1-(1/(1+exp(z_6[2]*Z[k+2]))))^(data_Y[k+1]-i)))
      }
    }
    L_6 <- -sum(log(p_6))
    return(L_6)
  }
  
  cmleG<-suppressWarnings(optim(initialvalues, GINARlik, method="BFGS")$par)
  beta_hat[kk] <- cmleG[1]
  gamma_hat[kk] <- cmleG[2]
  
}  

beta_hat_mean=mean(beta_hat)
gamma_hat_mean=mean(gamma_hat)

############################Phase-II 

T=60
N=700
T1=N-T

X=Z=scale(data_count$sales)
Z=c(0,Z)
X=c(0,0,X)


############################test sample 

e_control_limit=4.39
loop=2000
###no shift

rl=rep(0,loop)
for (ll in 1:loop) {
  
  X[107:(N+2)]=rnorm((N-104), 0, 1)
  Z[106:(N+1)]=X[107:(N+2)]
  
  alpha_hat=rep(0,T1)###sample (T+1):N
  for (t in 1:T1) {
    
    alpha_hat[t]=exp(beta_hat_mean*X[(t+(T-1)+2)])/(1+exp(beta_hat_mean*X[(t+(T-1)+2)]))
    
  }
  
  phi_hat=rep(0,T1)
  for (t in 1:T1) {
    
    phi_hat[t]=1/(1+exp(gamma_hat_mean*Z[(t+(T-1)+2)]))
    
  }
  
  data_Y_ex=c()
  Y=data_Y_orin[T]
  for(t in 1:T1) {
    Y <- rbinom(1,Y,alpha_hat[t])+rgeom(1,phi_hat[t])
    data_Y_ex <- c(data_Y_ex,Y)
  }
  data_Y[(T+1):N]=data_Y_ex
  data_Y[T]=data_Y_orin[T]
  ########################################model_based
  
  residual=rep(0,T1)
  for (t in T:(N-1)) {
    
    residual[t-T+1]=(data_Y[(t+1)]-(alpha_hat[t-T+1]*data_Y[t]+(1-phi_hat[t-T+1])/phi_hat[t-T+1]))/
      sqrt(alpha_hat[t-(T-1)]*(1-alpha_hat[t-(T-1)])*data_Y[t]+(1-phi_hat[t-(T-1)])/(phi_hat[t-(T-1)]^2))
    
  }
  
  ##############################control chart
  
  if(min(which(residual>e_control_limit)) < Inf){
    rl[ll]=min(which(residual>e_control_limit))
  }
  if(min(which(residual>e_control_limit))==Inf){
    rl[ll]=T1
  }
  print(c(ll,rl[ll]))
}
median(rl)
rl_m=median(rl)
rl_m

write.csv(c(rl_m,e_control_limit),file = "G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\C-INAR(1)-G\\Transmission\\UCL.csv")


