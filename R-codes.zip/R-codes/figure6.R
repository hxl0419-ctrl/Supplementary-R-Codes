library(ggplot2)
library(scales)
library(gridExtra)  


jpeg(filename = "G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\figure\\Figure_6.jpeg", width = 2000, height = 1700, quality = 5000, res = 200)
layout(matrix(1:4, nrow=2))



data_count_c <- read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\C-INAR(1)-G\\Brake\\Phase-II.csv", header = TRUE)  
data_count_s <- read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\SDC-INAR(1)-G\\Brake\\Phase-II.csv", header = TRUE)
data_count_I <- read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\INAR(1)-G\\Brake\\Phase-II.csv", header = TRUE)
data_count_w <- read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\WDC-INAR(1)-G\\Brake\\Phase-II.csv", header = TRUE)


df_ns <- data.frame(
  date_x = seq(as.Date('2020/05/1'), as.Date('2023/12/31'), by = "month"),
  value = data_count_c$Residual,
  type = "No State Space"
)

df_s <- data.frame(
  date_x = seq(as.Date('2020/05/1'), as.Date('2023/12/31'), by = "month"),
  value = data_count_s$Statistics,
  type = "State Space"
)

df_nsnc <- data.frame(
  date_x = seq(as.Date('2020/05/1'), as.Date('2023/12/31'), by = "month"),
  value = data_count_I$Residual,
  type = "No State Space No Covariate"
)

df_w <- data.frame(
  date_x = seq(as.Date('2020/05/1'), as.Date('2023/12/31'), by = "month"),
  value = data_count_w$Statistics,
  type = "Window"
)


create_plot <- function(df, title, ucl_value, ucl_label) {
  ggplot(df, aes(x = date_x, y = value)) +  
    geom_line() +  
    geom_point() +  
    geom_hline(yintercept = ucl_value, color = "blue", linetype = "dashed") +  
    annotate("text", x = min(df$date_x) + 500,
             y = ucl_value + 0.8,  
             label = ucl_label,
             hjust = 0) +
    labs(
      x = "Date (year/month)",
      y = "Plotting Statistic",
      title = title
    ) +  
    theme(panel.background = element_blank(),  
          panel.grid.major = element_blank(),  
          panel.grid.minor = element_blank(),  
          axis.line = element_line(colour = "black"),  
          axis.ticks = element_line(colour = "black"),  
          axis.text.x = element_text(angle = 45, hjust = 1, size = 8),
          plot.title = element_text(size = 10)
    ) +  
    scale_x_date(
      breaks = date_breaks("3 months"),  # Fewer breaks for cleaner look
      labels = date_format("%Y/%m"),
      limits = c(as.Date('2020/05/1'), as.Date('2023/12/31'))
    )
}


ucl_values <- list(
  list(df = df_ns, title = "C-INAR(1)-G", ucl_value = 4.42, ucl_label = expression(italic(UCL)[C]==4.42)),
  list(df = df_s, title = "SDC-INAR(1)-G", ucl_value = 7.27, ucl_label = expression(italic(UCL)[S]==7.27)),
  list(df = df_nsnc, title = "INAR(1)-G", ucl_value = 4.47, ucl_label = expression(italic(UCL)[I]==4.47)),
  list(df = df_w, title = "WDC-INAR(1)-G", ucl_value = 13.01, ucl_label = expression(italic(UCL)[W]==13.01))
)


plots <- lapply(ucl_values, function(params) {
  create_plot(params$df, params$title, params$ucl_value, params$ucl_label)
})


plot_ns <- plots[[1]]
plot_s <- plots[[2]]
plot_nsnc <- plots[[3]]
plot_w <- plots[[4]]

grid.arrange(plot_s, plot_ns, plot_nsnc, plot_w, 
             nrow = 2, ncol = 2)

dev.off()