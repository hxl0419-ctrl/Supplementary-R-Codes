alpha_shift_s=read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\SDC-INAR(1)-G\\Scenario_A\\Phase-II_Case-I.csv")
alpha_shift_o=read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\OD\\Scenario_A\\Phase-II_Case-I.csv")
alpha_shift_r=read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\SDC-INAR(1)-G-R\\Scenario_A\\Phase-II_Case-I.csv")
phi_shift_s=read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\SDC-INAR(1)-G\\Scenario_A\\Phase-II_Case-II.csv")
phi_shift_o=read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\OD\\Scenario_A\\Phase-II_Case-II.csv")
phi_shift_r=read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\SDC-INAR(1)-G-R\\Scenario_A\\Phase-II_Case-II.csv")
alpha_phi_shift_s=read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\SDC-INAR(1)-G\\Scenario_A\\Phase-II_Case-III.csv")
alpha_phi_shift_o=read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\OD\\Scenario_A\\Phase-II_Case-III.csv")
alpha_phi_shift_r=read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\SDC-INAR(1)-G-R\\Scenario_A\\Phase-II_Case-III.csv")
phi_alpha_shift_s=read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\SDC-INAR(1)-G\\Scenario_A\\Phase-II_Case-IV.csv")
phi_alpha_shift_o=read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\OD\\Scenario_A\\Phase-II_Case-IV.csv")
phi_alpha_shift_r=read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\SDC-INAR(1)-G-R\\Scenario_A\\Phase-II_Case-IV.csv")


jpeg(filename = "G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\figure\\Figure_R2.jpeg", width = 2000, height = 1700, quality = 5000, res = 200)
layout(matrix(1:4, nrow=2))


legend_labels <- c("SDC-INAR(1)-G", "OD", "SDC-INAR(1)-G-R")
legend_lty <- c(1, 2, 3, 4) 
legend_pch <- c(2, 18, 4, 1) 

############################################# alpha_shift
rl <- c(0, 0.1, 0.2, 0.4, 0.6, 0.8, 1, 1.2)
max_mrl <- max(alpha_shift_s$MRL, alpha_shift_o$MRL, alpha_shift_r$MRL, na.rm = TRUE)
plot(rl, alpha_shift_s$MRL, type="o", lty=legend_lty[1], pch=legend_pch[1], 
     xlab=expression(delta[1]), ylab="MRL", main="Scenario A", 
     sub="Case I Shift (autocorrelation alternative)", 
     ylim=c(0, max_mrl * 1.25))
lines(rl, alpha_shift_o$MRL, type="o", lty=legend_lty[2], pch=legend_pch[2])
lines(rl, alpha_shift_r$MRL, type="o", lty=legend_lty[3], pch=legend_pch[3])
legend("topright", legend=legend_labels, lty=legend_lty, pch=legend_pch, bty="n")

############################################# alpha_phi_shift(alpha fix)
rl <- c(0, 0.02, 0.04, 0.06, 0.08, 0.1, 0.2, 0.4)
max_mrl_alpha_phi <- max(alpha_phi_shift_s$MRL, alpha_phi_shift_o$MRL, alpha_phi_shift_r$MRL, na.rm=TRUE)
plot(rl, alpha_phi_shift_s$MRL, type="o", lty=legend_lty[1], pch=legend_pch[1], 
     xlab=expression(paste(delta[2],"  ","(",delta[1]==0.4,")")), 
     main="Scenario A", ylab="MRL", 
     sub="Case III Shift (mixed alternative)", 
     ylim=c(0, max_mrl_alpha_phi * 1.25))
lines(rl, alpha_phi_shift_o$MRL, type="o", lty=legend_lty[2], pch=legend_pch[2])
lines(rl, alpha_phi_shift_r$MRL, type="o", lty=legend_lty[3], pch=legend_pch[3])
legend("topright", legend=legend_labels, lty=legend_lty, pch=legend_pch, bty="n")

############################################# phi_shift
rl <- c(0, 0.02, 0.04, 0.06, 0.08, 0.1, 0.2, 0.4)
max_mrl_phi <- max(phi_shift_s$MRL, phi_shift_o$MRL, phi_shift_r$MRL, na.rm=TRUE)
plot(rl, phi_shift_s$MRL, type="o", lty=legend_lty[1], pch=legend_pch[1], 
     xlab=expression(delta[2]), main="Scenario A", ylab="MRL", 
     sub="Case II Shift (innovation alternative)", 
     ylim=c(0, max_mrl_phi * 1.25))
lines(rl, phi_shift_o$MRL, type="o", lty=legend_lty[2], pch=legend_pch[2])
lines(rl, phi_shift_r$MRL, type="o", lty=legend_lty[3], pch=legend_pch[3])
legend("topright", legend=legend_labels, lty=legend_lty, pch=legend_pch, bty="n")

############################################# phi_alpha_shift(phi fix)
rl <- c(0, 0.1, 0.2, 0.4, 0.6, 0.8, 1, 1.2)
max_mrl_phi_alpha <- max(phi_alpha_shift_s$MRL, phi_alpha_shift_o$MRL, phi_alpha_shift_r$MRL, na.rm=TRUE)
plot(rl, phi_alpha_shift_s$MRL, type="o", lty=legend_lty[1], pch=legend_pch[1], 
     xlab=expression(paste(delta[1],"  ","(",delta[2]==0.04,")")), 
     main="Scenario A", ylab="MRL", 
     sub="Case IV Shift (mixed alternative)", 
     ylim=c(0, max_mrl_phi_alpha * 1.25))
lines(rl, phi_alpha_shift_o$MRL, type="o", lty=legend_lty[2], pch=legend_pch[2])
lines(rl, phi_alpha_shift_r$MRL, type="o", lty=legend_lty[3], pch=legend_pch[3])
legend("topright", legend=legend_labels, lty=legend_lty, pch=legend_pch, bty="n")

dev.off()
