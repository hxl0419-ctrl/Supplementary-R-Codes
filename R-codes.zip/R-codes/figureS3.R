library(ggplot2)
library(gridExtra)  
library(dfphase1)
library(grid)       


residual_s <- read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\SDC-INAR(1)-G\\transmission\\Phase-I_Residual.csv")
residual_c <- read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\C-INAR(1)-G\\transmission\\Phase-I_Residual.csv")
residual_I <- read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\INAR(1)-G\\transmission\\Phase-I_Residual.csv")
residual_w <- read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\WDC-INAR(1)-G\\transmission\\Phase-I_Residual.csv")


if(is.data.frame(residual_s)) residual_s <- residual_s[,1]
if(is.data.frame(residual_c)) residual_c <- residual_c[,1]
if(is.data.frame(residual_I)) residual_I <- residual_I[,1]
if(is.data.frame(residual_w)) residual_w <- residual_w[,1]


jpeg(filename = "G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\figure\\Figure_S3.jpeg",
     width = 3000, 
     height = 2000, 
     res = 300, 
     quality = 100)



# SDC-INAR(1)-G 
plot_s <- ggplot(data.frame(Time = 1:length(residual_s), Residual = residual_s), 
                 aes(x = Time, y = Residual)) +
  geom_line(color = "steelblue", alpha = 0.8, size = 0.6) +
  geom_point(color = "steelblue", alpha = 0.7, size = 1.5) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red", size = 0.8) +
  geom_hline(yintercept = mean(residual_s, na.rm = TRUE), linetype = "dotted", color = "darkgreen", size = 0.6) +
  labs(title = "SDC-INAR(1)-G", x = "Time", y = "Residual") +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14, face = "bold", margin = margin(b = 10)),
    axis.title = element_text(size = 12),
    axis.text = element_text(size = 10),
    panel.grid.major = element_line(color = "grey90", size = 0.2),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "grey80", fill = NA, size = 0.5),
    plot.margin = margin(10, 10, 10, 10)
  )

# C-INAR(1)-G 
plot_c <- ggplot(data.frame(Time = 1:length(residual_c), Residual = residual_c), 
                 aes(x = Time, y = Residual)) +
  geom_line(color = "#E69F00", alpha = 0.8, size = 0.6) +
  geom_point(color = "#E69F00", alpha = 0.7, size = 1.5) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red", size = 0.8) +
  geom_hline(yintercept = mean(residual_c, na.rm = TRUE), linetype = "dotted", color = "darkgreen", size = 0.6) +
  labs(title = "C-INAR(1)-G", x = "Time", y = "Residual") +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14, face = "bold", margin = margin(b = 10)),
    axis.title = element_text(size = 12),
    axis.text = element_text(size = 10),
    panel.grid.major = element_line(color = "grey90", size = 0.2),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "grey80", fill = NA, size = 0.5),
    plot.margin = margin(10, 10, 10, 10)
  )

# INAR(1)-G 
plot_I <- ggplot(data.frame(Time = 1:length(residual_I), Residual = residual_I), 
                 aes(x = Time, y = Residual)) +
  geom_line(color = "#56B4E9", alpha = 0.8, size = 0.6) +
  geom_point(color = "#56B4E9", alpha = 0.7, size = 1.5) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red", size = 0.8) +
  geom_hline(yintercept = mean(residual_I, na.rm = TRUE), linetype = "dotted", color = "darkgreen", size = 0.6) +
  labs(title = "INAR(1)-G", x = "Time", y = "Residual") +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14, face = "bold", margin = margin(b = 10)),
    axis.title = element_text(size = 12),
    axis.text = element_text(size = 10),
    panel.grid.major = element_line(color = "grey90", size = 0.2),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "grey80", fill = NA, size = 0.5),
    plot.margin = margin(10, 10, 10, 10)
  )

# WDC-INAR(1)-G 
plot_w <- ggplot(data.frame(Time = 1:length(residual_w), Residual = residual_w), 
                 aes(x = Time, y = Residual)) +
  geom_line(color = "#009E73", alpha = 0.8, size = 0.6) +
  geom_point(color = "#009E73", alpha = 0.7, size = 1.5) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red", size = 0.8) +
  geom_hline(yintercept = mean(residual_w, na.rm = TRUE), linetype = "dotted", color = "darkgreen", size = 0.6) +
  labs(title = "WDC-INAR(1)-G", x = "Time", y = "Residual") +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14, face = "bold", margin = margin(b = 10)),
    axis.title = element_text(size = 12),
    axis.text = element_text(size = 10),
    panel.grid.major = element_line(color = "grey90", size = 0.2),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "grey80", fill = NA, size = 0.5),
    plot.margin = margin(10, 10, 10, 10)
  )

# ====== 组合为 2x2 布局 ======
grid.arrange(
  plot_s, plot_c, 
  plot_I, plot_w,
  nrow = 2, ncol = 2,
  top = textGrob("", 
                 gp = gpar(fontsize = 18, fontface = "bold", fontfamily = "sans"),
                 vjust = 1)
)

# 关闭图形设备
dev.off()