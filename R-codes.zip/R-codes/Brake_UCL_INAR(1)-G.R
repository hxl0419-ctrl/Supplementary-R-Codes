library("vars")
library("MASS")
library("stats4")
library("splines")
library("VGAM")
library("tcltk")
library("gamlss")
library("HMMpa")
library("Rsolnp")
library("tseries")

data_count=read.csv("E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\data\\freq_brake_noise_month_201505_202312.csv",header = T)

data_Y=data_count$MF[1:60]
data_Y_orin=data_Y
set.seed(1)

T <- 60

S <- 2
loop=100
m=1
epsi_mu=rep(0,(2*m))

###revised moving block bootstrap (MBB) approach
data_Y_number=tsbootstrap(1:60,nb=99,b=33,type = "block")
data_Y_number=cbind(1:60,data_Y_number)
data_Y_boot <- apply(data_Y_number, 2, function(col) data_Y[col])



##############parameter estimate 
alpha_hat=rep(0,loop)
phi_hat=rep(0,loop)
for (kk in 1:loop) {
  data_Y=as.numeric(data_Y_boot[,kk])
  T=33
  L_6 <- 0
  p_6 <- rep(0,(T-1))
  z_6 <- rep(NA,2)
  
  mybeta=0.5
  
  mygama=0.5
  
  initialvalues <- c(mybeta, mygama)
  
  GINARlik=function(z_6){
    
    
    for(k in 1:(T-1)){
      minX <- ifelse(data_Y[k]<data_Y[k+1],data_Y[k],data_Y[k+1])
      for(i in 0:minX){
        p_6[k] <- p_6[k]+choose(data_Y[k],i)*(z_6[1]^i)*((1-z_6[1])^(data_Y[k]-i))*(z_6[2]*((1-z_6[2])^(data_Y[k+1]-i)))
        
      }
    }
    L_6 <- -sum(log(p_6))
    return(L_6)
  }
  
  cmleG<-suppressWarnings(optim(initialvalues, GINARlik, method="BFGS")$par)
  
  alpha_hat[kk] <- cmleG[1]
  phi_hat[kk] <- cmleG[2]
}

alpha_hat_mean=mean(alpha_hat)
phi_hat_mean=mean(phi_hat)



############################phase-II 
T=60
N=700
T1=N-T
e_control_limit=4.47
loop=2000

rl=rep(0,loop)
for (ll in 1:loop) {
  
  
  data_Y_ex=c()
  Y=data_Y_orin[T]
  for(t in (T+1):N) {
    Y <- rbinom(1,Y,alpha_hat_mean)+rgeom(1,phi_hat_mean)
    data_Y_ex <- c(data_Y_ex,Y)
  }
  data_Y[(T+1):N]=data_Y_ex
  data_Y[T]=data_Y_orin[T]
  
  
  residual=rep(0,T1)
  for (t in T:(N-1)) {
    
    residual[t-T+1]=(data_Y[(t+1)]-(alpha_hat_mean*data_Y[t]+(1-phi_hat_mean)/phi_hat_mean))/
      sqrt(alpha_hat_mean*(1-alpha_hat_mean)*data_Y[t]+(1-phi_hat_mean)/(phi_hat_mean^2))
    
    
  }
  
  ##############################control chart
  
  if(min(which(residual>e_control_limit)) < Inf){
    rl[ll]=min(which(residual>e_control_limit))
  }
  if(min(which(residual>e_control_limit))==Inf){
    rl[ll]=T1
  }
  print(c(ll,rl[ll]))
}
median(rl)
rl_m=median(rl)
  

rl_m

write.csv(c(rl_m,e_control_limit),file = "E:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\INAR(1)-G\\Brake\\UCL.csv")


