library(ggplot2)
library(gridExtra)  
library(dfphase1)
library(grid)       


residual_s <- read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\SDC-INAR(1)-G\\brake\\Phase-I_Residual.csv")
residual_c <- read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\C-INAR(1)-G\\brake\\Phase-I_Residual.csv")
residual_I <- read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\INAR(1)-G\\brake\\Phase-I_Residual.csv")
residual_w <- read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\WDC-INAR(1)-G\\brake\\Phase-I_Residual.csv")


if(is.data.frame(residual_s)) residual_s <- residual_s[,1]
if(is.data.frame(residual_c)) residual_c <- residual_c[,1]
if(is.data.frame(residual_I)) residual_I <- residual_I[,1]
if(is.data.frame(residual_w)) residual_w <- residual_w[,1]


jpeg(filename = "G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\figure\\Figure_S2.jpeg",
     width = 3000, 
     height = 2000, 
     res = 300, 
     quality = 100)



# SDC-INAR(1)-G RSP
create_rsp_s <- function() {
  rsp(residual_s,alpha=0.01)
  grid::grid.text(
    "SDC-INAR(1)-G", 
    x = unit(0.5, "npc"),    
    y = unit(0.95, "npc"),   
    gp = gpar(
      col = "black", 
      fontsize = 12, 
      fontface = "bold"
    ),
    just = "center"
  )
}

# C-INAR(1)-G RSP
create_rsp_c <- function() {
  rsp(residual_c,alpha=0.01)
  grid::grid.text(
    "C-INAR(1)-G", 
    x = unit(0.5, "npc"),
    y = unit(0.95, "npc"),
    gp = gpar(
      col = "black", 
      fontsize = 12, 
      fontface = "bold"
    ),
    just = "center"
  )
}

# INAR(1)-G RSP
create_rsp_I <- function() {
  rsp(residual_I,alpha=0.01)
  grid::grid.text(
    "INAR(1)-G", 
    x = unit(0.5, "npc"),
    y = unit(0.95, "npc"),
    gp = gpar(
      col = "black", 
      fontsize = 12, 
      fontface = "bold"
    ),
    just = "center"
  )
}

# WDC-INAR(1)-G RSP
create_rsp_w <- function() {
  rsp(residual_w,alpha=0.01)
  grid::grid.text(
    "WDC-INAR(1)-G", 
    x = unit(0.5, "npc"),
    y = unit(0.95, "npc"),
    gp = gpar(
      col = "black", 
      fontsize = 12, 
      fontface = "bold"
    ),
    just = "center"
  )
}


grid::grid.newpage()
rsp_grob1 <- grid::grid.grabExpr(create_rsp_s())
grid::grid.newpage()
rsp_grob2 <- grid::grid.grabExpr(create_rsp_c())
grid::grid.newpage()
rsp_grob3 <- grid::grid.grabExpr(create_rsp_I())
grid::grid.newpage()
rsp_grob4 <- grid::grid.grabExpr(create_rsp_w())


grid.arrange(
  rsp_grob1, rsp_grob2, 
  rsp_grob3, rsp_grob4,
  nrow = 2, ncol = 2,
  top = textGrob("", 
                 gp = gpar(fontsize = 16, fontface = "bold"))
)

# 关闭图形设备
dev.off()