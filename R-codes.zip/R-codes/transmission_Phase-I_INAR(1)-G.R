library("vars")
library("MASS")
library("stats4")
library("splines")
library("VGAM")
library("tcltk")
library("gamlss")
library("HMMpa")
library("Rsolnp")
library("tseries")
library("dfphase1")

###########
data_count_bsx=read.csv("G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\data\\freq_transmission_noise_month_201505_202312.csv",header = T)

data_Y=data_count_bsx[1:60,2]
data_Y_orin=data_Y

set.seed(1)

T <- 60

S <- 2
loop=100
m=1
epsi_mu=rep(0,(2*m))

###revised moving block bootstrap (MBB) approach
data_Y_number=tsbootstrap(1:60,nb=99,b=33,type = "block")
data_Y_number=cbind(1:60,data_Y_number)
data_Y_boot <- apply(data_Y_number, 2, function(col) data_Y[col])



##############parameter estimate 
alpha_hat=rep(0,loop)
phi_hat=rep(0,loop)
for (kk in 1:loop) {
  data_Y=as.numeric(data_Y_boot[,kk])
  T=33
  L_6 <- 0
  p_6 <- rep(0,(T-1))
  z_6 <- rep(NA,2)
  
  mybeta=0.5
  
  mygama=0.5
  
  initialvalues <- c(mybeta, mygama)
  
  GINARlik=function(z_6){
    
    
    for(k in 1:(T-1)){
      minX <- ifelse(data_Y[k]<data_Y[k+1],data_Y[k],data_Y[k+1])
      for(i in 0:minX){
        p_6[k] <- p_6[k]+choose(data_Y[k],i)*(z_6[1]^i)*((1-z_6[1])^(data_Y[k]-i))*(z_6[2]*((1-z_6[2])^(data_Y[k+1]-i)))
        
      }
    }
    L_6 <- -sum(log(p_6))
    return(L_6)
  }
  
  cmleG<-suppressWarnings(optim(initialvalues, GINARlik, method="BFGS")$par)
  
  alpha_hat[kk] <- cmleG[1]
  phi_hat[kk] <- cmleG[2]
}

alpha_hat_mean=mean(alpha_hat)
phi_hat_mean=mean(phi_hat)

#Pearson residuals
cMeanP <- function(l,prob,alpha){
  alpha*l+(1-prob)/prob
}

cVarP <- function(l,prob,alpha){
  alpha*(1-alpha)*l+(1-prob)/(prob^2)
}

T=60

res <- (data_Y_orin[2:T]-cMeanP(data_Y_orin[1:(T-1)], phi_hat_mean, alpha_hat_mean))/sqrt(cVarP(data_Y_orin[1:(T-1)], phi_hat_mean,alpha_hat_mean))

write.table(res,file = "G:\\Seagate Expansion Drive-2025.2.25\\wh\\自相关的计数数据过程监控\\revise\\revise_R1\\result\\INAR(1)-G\\transmission\\Phase-I_residual.csv",col.names = "residual",row.names = FALSE,sep = ",")

plot(res)
mean(res)
var(res)
Box.test(res)
rsp(res,alpha=0.01)

#PIT:

# #Transition probabilities of INAR(1)-G model:
# tpgeom <- function(k,l,prob,alpha){
#   tp <- 0
#   for(j in c(0:min(k,l))){
#     tp <- tp + dbinom(j,l,alpha)*dgeom(k-j,prob)
#   }
#   tp
# }
# 
# 
# maxval <- max(data_Y_orin[1:T])
# maxval
# #Matrix of all CDFs:
# allcdfs <- array(0, c(maxval+2,maxval+1)) #additional zero row corresponding to F(-1)
# 
# for(l in c(0:maxval)){
#   cpmf <- rep(0, (maxval+1))
#   for(k in c(0:maxval)){
#     cpmf[k+1] <- tpgeom(k,l,phi_hat_mean,alpha_hat_mean)
#   }
#   allcdfs[(2:(maxval+2)),l+1] <- cumsum(cpmf)
# }
# 
# nobins <- 10
# PIT <- array(0, c(2,nobins+1))
# 
# for(j in c(1:nobins)){
#   u <- j/nobins
#   pitval <- 0
#   
#   for(t in c(2:T)){
#     if(allcdfs[(data_Y_orin[t]+1), (data_Y_orin[t-1]+1)]<u){
#       if(allcdfs[(data_Y_orin[t]+2), (data_Y_orin[t-1]+1)]<u){
#         pitval <- pitval+1
#       }else{
#         pitval <- pitval+ (u-allcdfs[(data_Y_orin[t]+1), (data_Y_orin[t-1]+1)])/(allcdfs[(data_Y_orin[t]+2), (data_Y_orin[t-1]+1)]-allcdfs[(data_Y_orin[t]+1), (data_Y_orin[t-1]+1)])
#       }
#     }
#   }
#   PIT[1,j+1] <- pitval/(T-1)
#   PIT[2,j+1] <- PIT[1,j+1]-PIT[1,j]
# }
# 
# PIT.freq= as.vector(rep(((1:nobins)-0.5)/nobins, PIT[2,2:(nobins+1)]*1000))
# PIT.hist <- hist(PIT.freq, plot=FALSE, breaks=nobins)
# PIT.hist$counts <- PIT.hist$counts/1000
# plot(PIT.hist, freq=TRUE, main="PIT histogram", ylab="PIT histogram", xlab="u", col="gray")
# 
# 
# 
# 
# 
# 
# 
